#!/usr/bin/env bash
# Builds and runs every host-side test (x86-64 gcc, AddressSanitizer + UBSan) and renders screenshots
# of the real GUI code into docs/screenshots/. No VM, GRUB or QEMU needed.
set -e
cd "$(dirname "$0")/../.."
OUT=${OUT:-/tmp/winlite-hosttest}; mkdir -p "$OUT"
CF="-std=gnu11 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -I. -Wall -Wno-unused-parameter -Wno-unused-function"
GUI="kernel/heap.c kernel/printf.c kernel/string.c fs/ramfs.c gui/gfx.c gui/theme.c gui/ui.c gui/wm.c gui/font8x16.c drivers/input.c apps/explorer.c apps/notepad.c apps/terminal.c apps/settings.c apps/apps.c kernel/boot_info.c gui/shell.c kernel/desktop.c drivers/keyboard.c drivers/mouse.c"
echo "== keyboard/mouse decoders";  gcc $CF -o $OUT/t_input tools/hosttest/test_input.c drivers/keyboard.c drivers/mouse.c drivers/input.c && $OUT/t_input
echo "== string/memory routines";   gcc $CF -o $OUT/t_string tools/hosttest/test_string.c && $OUT/t_string
echo "== 64-bit division helpers";  gcc -std=gnu11 -O2 -I. -o $OUT/t_div tools/hosttest/test_div.c && $OUT/t_div
echo "== RAM filesystem";           gcc $CF -o $OUT/t_fs tools/hosttest/test_fs.c kernel/heap.c kernel/printf.c kernel/string.c fs/ramfs.c && $OUT/t_fs
echo "== calculator logic";         gcc $CF -o $OUT/t_calc tools/hosttest/test_calc.c $GUI && $OUT/t_calc | tail -1
echo "== desktop simulation (real shell/WM/apps, scripted mouse+keyboard)"
gcc $CF -o $OUT/sim tools/hosttest/sim.c $GUI apps/calc.c
mkdir -p /tmp/shots && $OUT/sim | grep -E "FAIL|passed|FAILED"
if [ "$1" = "fuzz" ]; then echo "== fuzz (4 seeds x 15000 random events)"; $OUT/sim fuzz | tail -1; fi
if python3 -c "import PIL" 2>/dev/null; then
  mkdir -p docs/screenshots
  python3 - <<'PY'
from PIL import Image
import glob, os
for f in sorted(glob.glob('/tmp/shots/*.ppm')):
    Image.open(f).save('docs/screenshots/' + os.path.basename(f).replace('.ppm', '.png'))
print("screenshots written to docs/screenshots/")
PY
fi
echo "ALL HOST TESTS PASSED"
