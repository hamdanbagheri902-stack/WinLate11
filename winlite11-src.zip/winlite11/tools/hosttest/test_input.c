#include <stdio.h>
#include <string.h>
#include "../../drivers/input.h"
static int fails;
#define CHECK(c, m) do { if (!(c)) { printf("FAIL: %s\n", m); fails++; } } while (0)
static void keys(const u8 *s, int n) { for (int i = 0; i < n; i++) kbd_process_scancode(s[i]); }
int main(void) {
    KeyEvent e; MouseEvent m;
    /* Shift+h, e, l, l, o, Enter, then caps+a, ctrl+s, Left(E0 4B), Delete(E0 53), F2 */
    u8 s1[] = {0x2A,0x23,0xA3,0xAA, 0x12,0x92, 0x26,0xA6, 0x26,0xA6, 0x18,0x98, 0x1C,0x9C,
               0x3A,0xBA, 0x1E,0x9E, 0x3A,0xBA, 0x1D,0x1F,0x9F,0x9D, 0xE0,0x4B,0xE0,0xCB, 0xE0,0x53,0xE0,0xD3, 0x3C,0xBC,
               0x2A,0x02,0x82,0xAA, 0x2A,0x28,0xA8,0xAA};
    keys(s1, sizeof s1);
    const char *want = "Hello\n"; for (int i = 0; want[i]; i++) { CHECK(input_pop_key(&e) && e.key == want[i], "hello"); }
    CHECK(input_pop_key(&e) && e.key == 'A', "caps a");
    CHECK(input_pop_key(&e) && e.key == 's' && (e.mods & MOD_CTRL), "ctrl+s");
    CHECK(input_pop_key(&e) && e.key == KEY_LEFT, "left");
    CHECK(input_pop_key(&e) && e.key == KEY_DELETE, "delete");
    CHECK(input_pop_key(&e) && e.key == KEY_F2, "f2");
    CHECK(input_pop_key(&e) && e.key == '!', "shift+1");
    CHECK(input_pop_key(&e) && e.key == '"', "shift+'");
    CHECK(!input_pop_key(&e), "queue empty");
    /* mouse: right+down 5,3 (y up = +3 in ps2 -> screen dy -3) ; negative x */
    u8 p1[] = {0x08|0x01, 5, 3,   0x08|0x10|0x20, 0xFB, 0xFD}; /* second: dx=-5 dy=-3 -> screen dy=+3 */
    for (unsigned i = 0; i < sizeof p1; i++) mouse_feed_byte(p1[i]);
    CHECK(input_pop_mouse(&m) && m.dx == 5 && m.dy == -3 && m.buttons == 1, "pkt1");
    CHECK(input_pop_mouse(&m) && m.dx == -5 && m.dy == 3 && m.buttons == 0, "pkt2");
    mouse_feed_byte(0x00); mouse_feed_byte(0x08); mouse_feed_byte(1); mouse_feed_byte(1);  /* resync */
    CHECK(input_pop_mouse(&m) && m.dx == 1 && m.dy == -1, "resync");
    printf(fails ? "INPUT TESTS FAILED\n" : "input decoder tests: all passed\n");
    return fails;
}
