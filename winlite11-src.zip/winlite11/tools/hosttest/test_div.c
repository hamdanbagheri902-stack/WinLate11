/* Verify the freestanding 64-bit divide helpers against the host's native 64-bit division. */
#include <stdio.h>
#include <stdint.h>
#define __udivdi3 t_udivdi3
#define __umoddi3 t_umoddi3
#define __divdi3 t_divdi3
#define __moddi3 t_moddi3
#define __udivmoddi4 t_udivmoddi4
#include "../../kernel/divdi3.c"
int main(void) {
    uint64_t s = 88172645463325252ULL; int fails = 0; long n = 0;
    for (int i = 0; i < 200000; i++) {
        s ^= s << 13; s ^= s >> 7; s ^= s << 17; uint64_t a = s;
        s ^= s << 13; s ^= s >> 7; s ^= s << 17; uint64_t b = s >> (i % 64);
        if (!b) b = 1;
        int64_t sa = (int64_t)a, sb = (int64_t)b; if (sb == 0 || (sa == INT64_MIN && sb == -1)) continue;
        uint64_t r; 
        if (t_udivdi3(a, b) != a / b || t_umoddi3(a, b) != a % b || t_udivmoddi4(a, b, &r) != a / b || r != a % b) fails++;
        if (t_divdi3(sa, sb) != sa / sb || t_moddi3(sa, sb) != sa % sb) fails++;
        n++;
    }
    printf(fails ? "DIV TESTS FAILED (%d of %ld)\n" : "64-bit division helpers: %d failures over %ld cases\n", fails, n);
    return fails != 0;
}
