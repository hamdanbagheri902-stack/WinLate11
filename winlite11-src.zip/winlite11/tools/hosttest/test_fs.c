#include <stdio.h>
#include "../../kernel/klib.h"
#include "../../fs/ramfs.h"
static int fails;
#define CHECK(c, m) do { if (!(c)) { printf("  FAIL: %s\n", m); fails++; } } while (0)
int main(void) {
    fs_init(); FsNode *r = fs_root();
    CHECK(fs_lookup(0, "/Documents/Welcome.txt") != 0, "lookup abs");
    CHECK(fs_lookup(fs_lookup(0, "/Documents"), "../Desktop/hello.txt") != 0, "lookup relative with ..");
    CHECK(fs_lookup(0, "/documents/welcome.TXT") != 0, "lookup is case-insensitive");
    CHECK(fs_lookup(0, "/nope") == 0, "missing -> NULL");
    CHECK(fs_lookup(0, "/Documents/Welcome.txt/x") == 0, "cannot descend into a file");
    FsNode *d = fs_lookup(0, "/Documents");
    CHECK(fs_create(d, "a.txt", false) != 0, "create");
    CHECK(fs_create(d, "A.TXT", false) == 0, "duplicate (case-insens) rejected");
    CHECK(fs_create(d, "bad/name", false) == 0, "slash in name rejected");
    CHECK(fs_create(d, "", false) == 0 && fs_create(d, "..", false) == 0, "empty and .. rejected");
    CHECK(fs_create(d, "0123456789012345678901234567890123", false) == 0, "name over 31 chars rejected");
    FsNode *sub = fs_create(d, "zzdir", true);
    CHECK(d->child == fs_lookup(d, "zzdir"), "folders sort first");
    FsNode *f = fs_lookup(d, "a.txt");
    CHECK(fs_write(f, "hello", 5) && f->size == 5 && !memcmp(f->data, "hello", 5), "write");
    CHECK(fs_append(f, " world", 6) && f->size == 11 && !memcmp(f->data, "hello world", 11), "append");
    CHECK(fs_write(f, "x", 1) && f->size == 1, "overwrite shrinks");
    CHECK(fs_rename(f, "b.txt") && fs_lookup(d, "b.txt") == f && !fs_lookup(d, "a.txt"), "rename");
    CHECK(!fs_rename(f, "Todo.txt"), "rename onto existing rejected");
    FsNode *u1 = fs_unique(d, "New file", ".txt", false), *u2 = fs_unique(d, "New file", ".txt", false);
    CHECK(u1 && u2 && !strcmp(u1->name, "New file.txt") && !strcmp(u2->name, "New file 2.txt"), "unique names");
    char p[128]; fs_path(f, p, sizeof p); CHECK(!strcmp(p, "/Documents/b.txt"), "fs_path");
    fs_path(r, p, sizeof p); CHECK(!strcmp(p, "/"), "fs_path root");
    char leaf[32]; FsNode *pd = fs_lookup_parent(0, "/Documents/new.txt", leaf);
    CHECK(pd == d && !strcmp(leaf, "new.txt"), "lookup_parent abs");
    pd = fs_lookup_parent(d, "rel.txt", leaf); CHECK(pd == d && !strcmp(leaf, "rel.txt"), "lookup_parent relative");
    FsNode *child = fs_create(sub, "inner.txt", false);
    CHECK(fs_valid(child) && fs_valid(sub), "valid before remove");
    CHECK(fs_remove(sub) && !fs_valid(sub), "recursive remove");
    CHECK(!fs_remove(r), "cannot remove root");
    size_t used = kheap_used(); for (int i = 0; i < 200; i++) { FsNode *t = fs_create(d, "tmp", false); fs_write(t, "0123456789", 10); fs_remove(t); }
    CHECK(kheap_used() == used, "no heap leak over 200 create/write/remove cycles");
    printf(fails ? "FS TESTS FAILED\n" : "filesystem tests: all passed\n");
    return fails;
}
