/* Host-side simulator: runs the real shell/WM/apps against a fake framebuffer and dumps screenshots (PPM). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../../kernel/klib.h"
#include "../../kernel/boot_info.h"
#include "../../kernel/desktop.h"
#include "../../drivers/drivers.h"
#include "../../drivers/input.h"
#include "../../gui/shell.h"
#include "../../fs/ramfs.h"
#include "../../apps/apps.h"

/* ---- driver stubs ---- */
static u32 ticks;
u32 pit_ticks(void) { return ticks; }
void rtc_read(DateTime *d) { *d = (DateTime){ 2026, 10, 29, 14, 7, 0 }; }
static int power_calls;
void power_shutdown(void) { power_calls |= 1; }
void power_restart(void) { power_calls |= 2; }

static u8 *fbmem; static int fails;
#define CHECK(c, m) do { if (!(c)) { printf("  FAIL: %s\n", m); fails++; } else printf("  ok: %s\n", m); } while (0)

static void shot(const char *name) {
    desktop_step();
    char path[128]; snprintf(path, sizeof path, "/tmp/shots/%s.ppm", name);
    FILE *f = fopen(path, "wb"); fprintf(f, "P6\n%d %d\n255\n", gfx_w, gfx_h);
    for (int y = 0; y < gfx_h; y++) for (int x = 0; x < gfx_w; x++) {
        u32 v = ((u32 *)fbmem)[y * gfx_w + x]; u8 rgb[3] = { (v >> 16) & 255, (v >> 8) & 255, v & 255 }; fwrite(rgb, 1, 3, f);
    }
    fclose(f); printf("shot %s\n", name);
}
static int px = 512, py = 384, btn;
static void move_to(int x, int y) { input_push_mouse(x - px, y - py, btn); px = x; py = y; desktop_step(); }
static void click(int x, int y) {
    move_to(x, y); btn = 1; input_push_mouse(0, 0, 1); desktop_step();
    btn = 0; input_push_mouse(0, 0, 0); desktop_step();
}
static void drag(int x0, int y0, int x1, int y1) {
    move_to(x0, y0); btn = 1; input_push_mouse(0, 0, 1); desktop_step();
    for (int i = 1; i <= 8; i++) move_to(x0 + (x1 - x0) * i / 8, y0 + (y1 - y0) * i / 8);
    btn = 0; input_push_mouse(0, 0, 0); desktop_step();
}
static void key(int k, int mods) { input_push_key(k, mods); desktop_step(); }
static void type(const char *s) { for (; *s; s++) key(*s == '\n' ? KEY_ENTER : (u8)*s, 0); }
static void tick(u32 n) { ticks += n; desktop_step(); }

static void fuzz(unsigned seed, int iters);
int main(int argc, char **argv) {
    if (system("mkdir -p /tmp/shots")) return 2;
    fbmem = calloc(1024 * 768, 4);
    memset(&g_boot, 0, sizeof g_boot); g_boot.mem_kb = 523264;
    gfx_init(fbmem, 1024, 768, 1024 * 4, false);
    theme_init(); fs_init(); shell_init(); wall_render(T.wall_idx, T.dark);
    gfx_cursor_show(true); ui_invalidate();
    const int TB = 744, START = 400, EXPL = 444, NOTE = 488, CALC = 532, TERM = 576, SETT = 620;

    if (argc > 1 && !strcmp(argv[1], "fuzz")) { for (unsigned sd = 1; sd <= 4; sd++) fuzz(sd, 15000); printf("fuzz: no crashes, no sanitizer reports\n"); return 0; }
    printf("[desktop]\n"); shot("01_desktop");
    printf("[start menu]\n"); click(START, TB); shot("02_start");
    type("note"); shot("03_start_search");
    key(KEY_ENTER, 0); CHECK(wm_count_app(APP_NOTEPAD) == 1, "Enter in search launches Notepad");
    type("Hello from WinLite 11!\nSecond line here.\n\tTabbed text"); shot("04_notepad");
    printf("[apps]\n");
    click(EXPL, TB); click(CALC, TB); click(TERM, TB); click(SETT, TB);
    CHECK(wm_count() == 5, "five windows open");
    shot("05_all_windows");
    printf("[terminal]\n");
    Window *t = wm_find_app(APP_TERMINAL); wm_focus(t);
    type("help\n"); type("ls\n"); type("cat Welcome.txt\n"); type("echo made in terminal > note1.txt\n"); type("ls\n"); type("cat note1.txt\n"); type("mem\n");
    shot("06_terminal");
    type("bogus\n"); type("mkdir Projects\n"); type("cd Projects\n"); type("pwd\n"); type("cd ..\n"); type("rm Projects\n"); type("ls\n");
    shot("07_terminal2");
    type("clear\n"); type("about\n"); type("theme accent 3\n"); shot("07b_terminal_about"); type("theme accent 0\n");
    printf("[calculator]\n");
    { Window *cw = wm_find_app(APP_CALC); wm_focus(cw); type("12+7*3="); cw->x = 300; cw->y = 40; shot("07c_calculator"); }
    printf("[quick settings -> dark]\n");
    click(1024 - 12 - 84 - 4 - 38, TB); shot("08_quick");
    { int qx = 1024 - 12 - 312, qy = 720 - 12 - 172; click(qx + 16 + 60, qy + 16 + 30); }
    CHECK(T.dark, "quick settings toggles dark mode"); shot("09_dark");
    printf("[window drag/maximize]\n"); printf("  notepad before: x=%d y=%d w=%d h=%d\n", wm_find_app(APP_NOTEPAD)->x, wm_find_app(APP_NOTEPAD)->y, wm_find_app(APP_NOTEPAD)->w, wm_find_app(APP_NOTEPAD)->h);
    Window *n = wm_find_app(APP_NOTEPAD); wm_focus(n);
    int ox = n->x, oy = n->y; drag(n->x + 200, n->y + 12, n->x + 260, n->y + 52);
    CHECK(n->x == ox + 60 && n->y == oy + 40, "title-bar drag moves window by the drag delta");
    int rw = n->w; drag(n->x + n->w - 4, n->y + n->h - 4, n->x + n->w + 60, n->y + n->h + 30);
    printf("  resize: rw=%d now w=%d h=%d x=%d y=%d\n", rw, n->w, n->h, n->x, n->y);
    CHECK(n->w == rw + 64, "bottom-right grip resizes window by the pointer delta");
    click(n->x + n->w - 46 - 23, n->y + 16); CHECK(n->maximized, "maximize button maximizes"); shot("10_maximized");
    click(n->x + n->w - 46 - 23, n->y + 16); CHECK(!n->maximized, "maximize button restores");
    click(n->x + n->w - 92 - 23, n->y + 16); CHECK(n->minimized, "minimize button minimizes"); 
    click(NOTE, TB); CHECK(!n->minimized && wm_top() == n, "taskbar button restores window");
    printf("[explorer]\n");
    Window *e = wm_find_app(APP_EXPLORER); wm_focus(e); shot("11_explorer_before");
    click(e->x + 1 + 14 + 40, e->y + TITLE_H + 54 + 2 * 32 + 14); shot("12_explorer_docs");
    click(e->x + 1 + 8 + 150 + 8 + 60, e->y + TITLE_H + 76 + 14);   /* first row: Ideas.txt */
    key(KEY_F2, 0); type("Renamed.txt\n");
    CHECK(fs_lookup(0, "/Documents/Renamed.txt") != 0 && !fs_lookup(0, "/Documents/Ideas.txt"), "F2 rename replaces the old name");
    shot("13_explorer_rename");
    printf("[keyboard shortcuts]\n");
    key(KEY_SUPER, 0); CHECK(shell_start_visible(), "Windows key opens Start"); key(KEY_ESC, 0); CHECK(!shell_start_visible(), "Esc closes Start");
    key(KEY_SUPER, 0); key(KEY_SUPER, 0); CHECK(!shell_start_visible(), "Windows key toggles Start");
    Window *topw = wm_top(); key(KEY_TAB, MOD_ALT); CHECK(wm_top() != topw, "Alt+Tab switches window");
    wm_focus(wm_find_app(APP_NOTEPAD)); key('s', MOD_CTRL);
    { FsNode *sv = fs_lookup(0, "/Documents/Untitled.txt"); CHECK(sv && sv->size == 56, "Notepad Ctrl+S saves 56 bytes to /Documents/Untitled.txt"); }
    { int c0 = wm_count(); key(KEY_F4, MOD_ALT); CHECK(wm_count() == c0 - 1, "Alt+F4 closes the focused window"); }
    printf("[close]\n");
    int before = wm_count(); click(e->x + e->w - 23, e->y + 16); CHECK(wm_count() == before - 1, "close button closes window");
    printf("[power]\n");
    click(START, TB); { int x = (1024 - 560) / 2, h = 600, y = 720 - 12 - h; click(x + 560 - 24 - 36 + 18, y + h - 64 + 14 + 18); } shot("14_power_menu");
    { int x = (1024 - 560) / 2, h = 600, y = 720 - 12 - h; int bx = x + 560 - 24 - 36, by = y + h - 64 + 14; int px2 = bx + 36 - 150, py2 = by - 8 - 80; click(px2 + 40, py2 + 4 + 36 + 10); }
    CHECK(shell_power_state() == POWER_RESTART, "Restart menu item starts restart"); shot("15_restarting");
    tick(200); CHECK(power_calls & 2, "restart reaches power_restart()");
    printf("%s\n", fails ? "SIMULATION FAILED" : "simulation: all checks passed");
    return fails;
}

static unsigned rs;
static unsigned rnd(void) { rs = rs * 1664525u + 1013904223u; return rs >> 8; }
static void fuzz(unsigned seed, int iters) {
    rs = seed * 7919u;
    static const int keys[] = { KEY_ENTER, KEY_BACKSPACE, KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT, KEY_HOME, KEY_END, KEY_DELETE, KEY_ESC, KEY_TAB, KEY_F2, KEY_PGUP, KEY_PGDN, KEY_SUPER };
    for (int i = 0; i < iters; i++) {
        unsigned r = rnd() % 100;
        if (r < 35) { int x = rnd() % 1024, y = rnd() % 768; move_to(x, y); }
        else if (r < 55) click(rnd() % 1024, rnd() % 768);
        else if (r < 62) click(380 + (rnd() % 6) * 44 + 20, 744);                 /* taskbar buttons */
        else if (r < 68) drag(rnd() % 1024, rnd() % 768, rnd() % 1024, rnd() % 768);
        else if (r < 90) key(32 + rnd() % 95, (rnd() % 8 == 0) ? MOD_CTRL : 0);
        else if (r < 97) key(keys[rnd() % (sizeof keys / sizeof keys[0])], (rnd() % 10 == 0) ? MOD_ALT : 0);
        else if (r < 99) key(KEY_F4, MOD_ALT);
        else { shell_set_theme(rnd() % 2, rnd() % 6, rnd() % 6); }
        if (rnd() % 50 == 0) tick(rnd() % 400);
        if (shell_power_state()) return;                      /* shutdown/restart is terminal in the real OS: stop this run */
    }
}
