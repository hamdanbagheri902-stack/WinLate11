/* Equivalence test: the kernel's own string/memory routines (incl. the inline-asm rep movsb/stosb ones) vs the host libc. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define memcpy  k_memcpy
#define memset  k_memset
#define memmove k_memmove
#define memcmp  k_memcmp
#define strlen  k_strlen
#define strcmp  k_strcmp
#define strncmp k_strncmp
#define __i386__ 1
#include "../../kernel/string.c"
#undef memcpy
#undef memset
#undef memmove
#undef memcmp
#undef strlen
#undef strcmp
#undef strncmp
#undef __i386__
static unsigned s = 12345; static unsigned rnd(void) { s = s * 1103515245u + 12345u; return s >> 8; }
int main(void) {
    static unsigned char a[512], b[512], c[512]; int fails = 0;
    for (int it = 0; it < 20000; it++) {
        size_t n = rnd() % 200, o1 = rnd() % 64, o2 = rnd() % 64;
        for (int i = 0; i < 512; i++) a[i] = rnd();
        memcpy(b, a, 512); memcpy(c, a, 512);
        k_memcpy(b + o1, a + o2, n); memcpy(c + o1, a + o2, n); if (memcmp(b, c, 512)) fails++;
        memcpy(b, a, 512); memcpy(c, a, 512);
        k_memmove(b + o1, b + o2, n); memmove(c + o1, c + o2, n); if (memcmp(b, c, 512)) fails++;     /* overlapping both ways */
        int v = rnd() & 255; k_memset(b + o1, v, n); memset(c + o1, v, n); if (memcmp(b, c, 512)) fails++;
        int r1 = k_memcmp(a, b, n), r2 = memcmp(a, b, n); if ((r1 > 0) != (r2 > 0) || (r1 < 0) != (r2 < 0)) fails++;
        char s1[40], s2[40]; for (int i = 0; i < 39; i++) { s1[i] = 'a' + rnd() % 3; s2[i] = 'a' + rnd() % 3; } s1[rnd() % 39] = 0; s2[rnd() % 39] = 0; s1[39] = s2[39] = 0;
        if (k_strlen(s1) != strlen(s1)) fails++;
        int d1 = k_strcmp(s1, s2), d2 = strcmp(s1, s2); if ((d1 > 0) != (d2 > 0) || (d1 < 0) != (d2 < 0)) fails++;
        size_t m = rnd() % 10; d1 = k_strncmp(s1, s2, m); d2 = strncmp(s1, s2, m); if ((d1 > 0) != (d2 > 0) || (d1 < 0) != (d2 < 0)) fails++;
    }
    printf(fails ? "STRING TESTS FAILED (%d)\n" : "string/memory routines: all passed (%d failures)\n", fails);
    return fails != 0;
}
