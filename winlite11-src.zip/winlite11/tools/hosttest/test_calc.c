/* Calculator logic tests: includes calc.c to reach its static press()/fmt(). */
#include <stdio.h>
#include "../../drivers/drivers.h"
#include "../../apps/calc.c"
u32 pit_ticks(void) { return 0; }
void rtc_read(DateTime *d) { (void)d; }
void power_shutdown(void) {}
void power_restart(void) {}
static int fails;
static const char *run(const char *keys) {
    static Calc c; static char out[40];
    reset(&c);
    for (const char *k = keys; *k; k++) press(&c, *k);
    if (c.err) return c.err;
    if (c.typing) kstrlcpy(out, c.entry, sizeof out); else fmt(c.shown, out, sizeof out);
    return out;
}
static void t(const char *keys, const char *want) {
    const char *got = run(keys);
    int ok = !strcmp(got, want);
    if (!ok) fails++;
    printf("  %s  %-22s -> %-24s %s\n", ok ? "ok  " : "FAIL", keys, got, ok ? "" : want);
}
int main(void) {
    t("12+7*3=", "57");           t("2.5*4=", "10");            t("10/4=", "2.5");
    t("1/3=", "0.3333");          t("0.1+0.2=", "0.3");         t("5/0=", "Cannot divide by zero");
    t("16r", "4");                t("2r", "1.4142");            t("1.5q", "2.25");
    t("4i", "0.25");              t("5n", "-5");                t("5n+3=", "-2");
    t("200+10%=", "220");         t("123b", "12");              t("1b", "0");
    t("999999999*999999999=", "Overflow");
    t("2+3=*4=", "20");           t("1.23456", "1.2345");       t("1234567890", "123456789");
    t("7-10=", "-3");             t("3*2n=", "-6");           t("3*-2=", "1");             t("9n r", "Invalid input");
    t("0.5*0.5=", "0.25");        t("100/8=", "12.5");          t("1+2+3+4=", "10");
    t("5+=", "10");               t("8*c3+4=", "7");            t("3e5+1=", "6");
    t("2.", "2.");                t("0.0001*0.0001=", "0");     t("n", "0");
    printf(fails ? "CALC TESTS FAILED (%d)\n" : "calculator tests: all passed\n", fails);
    return fails;
}
