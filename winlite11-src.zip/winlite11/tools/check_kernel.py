#!/usr/bin/env python3
"""Static sanity checks on kernel.elf: Multiboot2 header, ELF layout, entry point."""
import struct, sys
d = open(sys.argv[1], 'rb').read()
assert d[:4] == b'\x7fELF' and d[4] == 1, "not a 32-bit ELF"
entry = struct.unpack_from('<I', d, 24)[0]
phoff, = struct.unpack_from('<I', d, 28); phentsize, phnum = struct.unpack_from('<HH', d, 42)
print("entry point: 0x%x" % entry)
loads = []
for i in range(phnum):
    t, off, va, pa, fs, ms, fl, al = struct.unpack_from('<8I', d, phoff + i * phentsize)
    if t == 1: loads.append((va, pa, fs, ms)); print("LOAD va=0x%x pa=0x%x filesz=0x%x memsz=0x%x" % (va, pa, fs, ms))
assert loads and loads[0][1] == 0x100000, "first segment must load at 1 MiB"
assert 0x100000 <= entry < 0x100000 + loads[0][3] + 0x1000000, "entry outside image"
# Multiboot2 header must be 8-byte aligned and within the first 32 KiB of the file
i = next((o for o in range(0, min(len(d), 32768), 8) if struct.unpack_from('<I', d, o)[0] == 0xE85250D6), None)
assert i is not None, "Multiboot2 magic not found in first 32 KiB"
magic, arch, length, csum = struct.unpack_from('<4I', d, i)
assert (magic + arch + length + csum) & 0xFFFFFFFF == 0, "bad header checksum"
print("multiboot2 header at file offset 0x%x, length %d, checksum OK" % (i, length))
o, tags = i + 16, []
while o < i + length:
    t, f, s = struct.unpack_from('<HHI', d, o); tags.append((t, f, s))
    if t == 5: print("  framebuffer tag: %dx%dx%d flags=%d" % (*struct.unpack_from('<3I', d, o + 8), f))
    if t == 0: break
    o += (s + 7) & ~7; assert o % 8 == 0
assert tags[-1][0] == 0, "missing end tag"
print("tags:", tags); print("OK")
