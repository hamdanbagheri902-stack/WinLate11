#pragma once
#include "types.h"
typedef struct {
    bool has_fb;
    u32  fb_addr, fb_pitch, fb_w, fb_h;
    u8   fb_bpp, fb_type;
    u8   r_pos, g_pos, b_pos;
    u32  mem_kb;                 /* conventional + extended, from basic meminfo tag */
} BootInfo;
extern BootInfo g_boot;
#define MB2_BOOT_MAGIC 0x36d76289u
bool boot_info_parse(u32 magic, const void *mbi);
