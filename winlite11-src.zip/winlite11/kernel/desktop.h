#pragma once
void desktop_step(void);     /* drain input, tick the shell, redraw if needed */
void splash_boot(void);      /* boot splash + wallpaper build + fade into the desktop */
