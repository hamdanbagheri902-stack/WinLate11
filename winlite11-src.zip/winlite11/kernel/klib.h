#pragma once
#include "types.h"
/* --- string / memory (own implementations, no libc) --- */
void  *memcpy(void *d, const void *s, size_t n);
void  *memmove(void *d, const void *s, size_t n);
void  *memset(void *d, int c, size_t n);
int    memcmp(const void *a, const void *b, size_t n);
size_t strlen(const char *s);
int    strcmp(const char *a, const char *b);
int    strncmp(const char *a, const char *b, size_t n);
size_t kstrlcpy(char *dst, const char *src, size_t n);
size_t kstrlcat(char *dst, const char *src, size_t n);
int    ktolower(int c);
int    kstrcasecontains(const char *hay, const char *needle);
int    katoi(const char *s);
int    ksnprintf(char *buf, size_t n, const char *fmt, ...);
int    kvsnprintf(char *buf, size_t n, const char *fmt, va_list ap);
/* --- heap --- */
void  *kmalloc(size_t n);
void  *kzalloc(size_t n);
void  *krealloc(void *p, size_t n);
void   kfree(void *p);
size_t kheap_used(void);
size_t kheap_total(void);
