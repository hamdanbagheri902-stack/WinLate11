#pragma once
#include "types.h"
typedef struct { u32 edi, esi, ebp, esp, ebx, edx, ecx, eax, int_no, err_code, eip, cs, eflags; } Regs;
void gdt_init(void);
void idt_init(void);
void kpanic(const char *msg, const Regs *r);
static inline void sti(void) { __asm__ volatile("sti"); }
static inline void cli(void) { __asm__ volatile("cli"); }
static inline void hlt(void) { __asm__ volatile("hlt"); }
static inline void idle_wait(void) { __asm__ volatile("sti; hlt"); }   /* atomic: wake on next interrupt */
