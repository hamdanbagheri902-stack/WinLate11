#include "klib.h"

typedef struct { char *buf; size_t n, pos; } Out;
static void put(Out *o, char c) { if (o->pos + 1 < o->n) o->buf[o->pos] = c; o->pos++; }

static void put_num(Out *o, u32 v, int base, int upper, int width, int zero, int left, int neg) {
    char tmp[16]; int l = 0;
    const char *dg = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    do { tmp[l++] = dg[v % base]; v /= base; } while (v);
    int total = l + (neg ? 1 : 0);
    if (!left && !zero) for (int i = total; i < width; i++) put(o, ' ');
    if (neg) put(o, '-');
    if (!left && zero) for (int i = total; i < width; i++) put(o, '0');
    while (l) put(o, tmp[--l]);
    if (left) for (int i = total; i < width; i++) put(o, ' ');
}

int kvsnprintf(char *buf, size_t n, const char *fmt, va_list ap) {
    Out o = { buf, n, 0 };
    for (; *fmt; fmt++) {
        if (*fmt != '%') { put(&o, *fmt); continue; }
        fmt++;
        int zero = 0, left = 0, width = 0;
        for (;; fmt++) { if (*fmt == '0') zero = 1; else if (*fmt == '-') left = 1; else break; }
        while (*fmt >= '0' && *fmt <= '9') width = width * 10 + (*fmt++ - '0');
        while (*fmt == 'l') fmt++;
        switch (*fmt) {
        case 'd': case 'i': { i32 v = va_arg(ap, i32); put_num(&o, v < 0 ? -(u32)v : (u32)v, 10, 0, width, zero, left, v < 0); break; }
        case 'u': put_num(&o, va_arg(ap, u32), 10, 0, width, zero, left, 0); break;
        case 'x': put_num(&o, va_arg(ap, u32), 16, 0, width, zero, left, 0); break;
        case 'X': put_num(&o, va_arg(ap, u32), 16, 1, width, zero, left, 0); break;
        case 'c': put(&o, (char)va_arg(ap, int)); break;
        case 's': {
            const char *s = va_arg(ap, const char *); if (!s) s = "(null)";
            int l = (int)strlen(s);
            if (!left) for (int i = l; i < width; i++) put(&o, ' ');
            while (*s) put(&o, *s++);
            if (left) for (int i = l; i < width; i++) put(&o, ' ');
            break; }
        case '%': put(&o, '%'); break;
        case 0: fmt--; break;
        default: put(&o, '%'); put(&o, *fmt); break;
        }
    }
    if (n) o.buf[o.pos < n ? o.pos : n - 1] = 0;
    return (int)o.pos;
}
int ksnprintf(char *buf, size_t n, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    int r = kvsnprintf(buf, n, fmt, ap);
    va_end(ap);
    return r;
}
