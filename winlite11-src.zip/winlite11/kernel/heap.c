/* First-fit free-list allocator over a static arena (lives in .bss). */
#include "klib.h"

#define HEAP_SIZE (24u * 1024 * 1024)
static u8 arena[HEAP_SIZE] __attribute__((aligned(16)));

typedef struct Blk { u32 size; u32 used; struct Blk *next; u32 pad; } Blk;   /* 16 bytes */
static Blk *head;
static size_t used_bytes;

static void heap_init(void) {
    head = (Blk *)arena;
    head->size = HEAP_SIZE - sizeof(Blk); head->used = 0; head->next = 0;
}
void *kmalloc(size_t n) {
    if (!head) heap_init();
    if (!n) n = 1;
    n = (n + 15) & ~15u;
    for (Blk *b = head; b; b = b->next) {
        if (b->used || b->size < n) continue;
        if (b->size >= n + sizeof(Blk) + 32) {
            Blk *r = (Blk *)((u8 *)(b + 1) + n);
            r->size = b->size - n - sizeof(Blk); r->used = 0; r->next = b->next;
            b->size = n; b->next = r;
        }
        b->used = 1; used_bytes += b->size;
        return b + 1;
    }
    return 0;
}
void *kzalloc(size_t n) { void *p = kmalloc(n); if (p) memset(p, 0, n); return p; }
void kfree(void *p) {
    if (!p) return;
    Blk *b = (Blk *)p - 1;
    if (!b->used) return;
    b->used = 0; used_bytes -= b->size;
    for (Blk *c = head; c; c = c->next)                 /* coalesce */
        while (!c->used && c->next && !c->next->used) { c->size += sizeof(Blk) + c->next->size; c->next = c->next->next; }
}
void *krealloc(void *p, size_t n) {
    if (!p) return kmalloc(n);
    Blk *b = (Blk *)p - 1;
    if (b->size >= n) return p;
    void *q = kmalloc(n);
    if (q) { memcpy(q, p, b->size); kfree(p); }
    return q;
}
size_t kheap_used(void)  { return used_bytes; }
size_t kheap_total(void) { return HEAP_SIZE; }
