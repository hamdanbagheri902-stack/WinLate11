#include "klib.h"

#ifdef __i386__
void *memcpy(void *d, const void *s, size_t n) {
    void *r = d;
    __asm__ volatile("rep movsb" : "+D"(d), "+S"(s), "+c"(n) : : "memory");
    return r;
}
void *memset(void *d, int c, size_t n) {
    void *r = d;
    __asm__ volatile("rep stosb" : "+D"(d), "+c"(n) : "a"(c) : "memory");
    return r;
}
void *memmove(void *d, const void *s, size_t n) {
    u8 *dd = d; const u8 *ss = s;
    if (dd < ss || dd >= ss + n) return memcpy(d, s, n);
    while (n--) dd[n] = ss[n];
    return d;
}
int memcmp(const void *a, const void *b, size_t n) {
    const u8 *x = a, *y = b;
    for (; n; n--, x++, y++) if (*x != *y) return *x - *y;
    return 0;
}
size_t strlen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }
int strcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (u8)*a - (u8)*b;
}
int strncmp(const char *a, const char *b, size_t n) {
    for (; n; n--, a++, b++) { if (*a != *b) return (u8)*a - (u8)*b; if (!*a) return 0; }
    return 0;
}

#endif

size_t kstrlcpy(char *dst, const char *src, size_t n) {
    size_t l = strlen(src);
    if (n) { size_t c = l >= n ? n - 1 : l; memcpy(dst, src, c); dst[c] = 0; }
    return l;
}
size_t kstrlcat(char *dst, const char *src, size_t n) {
    size_t dl = strlen(dst);
    if (dl >= n) return dl + strlen(src);
    return dl + kstrlcpy(dst + dl, src, n - dl);
}
int ktolower(int c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }
int kstrcasecontains(const char *h, const char *nd) {
    if (!*nd) return 1;
    for (; *h; h++) {
        const char *a = h, *b = nd;
        while (*a && *b && ktolower(*a) == ktolower(*b)) { a++; b++; }
        if (!*b) return 1;
    }
    return 0;
}
int katoi(const char *s) {
    int neg = 0, v = 0;
    while (*s == ' ') s++;
    if (*s == '-') { neg = 1; s++; }
    while (*s >= '0' && *s <= '9') v = v * 10 + (*s++ - '0');
    return neg ? -v : v;
}
