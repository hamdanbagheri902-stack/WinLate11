/* WinLite 11 kernel entry: bring up CPU tables, interrupts, input, graphics, then run the desktop. */
#include "klib.h"
#include "cpu.h"
#include "boot_info.h"
#include "desktop.h"
#include "../drivers/drivers.h"
#include "../gui/shell.h"
#include "../gui/theme.h"
#include "../fs/ramfs.h"

void kernel_main(u32 magic, u32 mbi) {
    if (!boot_info_parse(magic, (const void *)mbi) || !g_boot.has_fb) {
        vga_show("WinLite 11\n\nGRUB did not provide a 32-bit linear framebuffer.\n\nIn VirtualBox: Graphics Controller = VBoxVGA, EFI disabled.\nBoot this ISO with the GRUB menu entry 'WinLite 11'.");
        cpu_halt_forever();
    }
    gdt_init(); idt_init(); pic_init(); pit_init(100); ps2_init();
    bool swap = g_boot.r_pos == 0 && g_boot.b_pos == 16;
    gfx_init((void *)g_boot.fb_addr, (int)g_boot.fb_w, (int)g_boot.fb_h, (int)g_boot.fb_pitch, swap);
    if (!gfx_ready) { vga_show("WinLite 11: out of memory allocating the back buffer."); cpu_halt_forever(); }
    theme_init(); fs_init(); shell_init();
    sti();
    splash_boot();
    gfx_cursor_show(true);
    ui_invalidate();
    for (;;) { desktop_step(); idle_wait(); }
}
