#include "boot_info.h"
#include "klib.h"

BootInfo g_boot;

typedef struct { u32 type, size; } __attribute__((packed)) MbTag;
typedef struct {
    MbTag t; u64 addr; u32 pitch, width, height; u8 bpp, fbtype; u16 reserved;
    u8 r_pos, r_size, g_pos, g_size, b_pos, b_size;
} __attribute__((packed)) MbFb;
typedef struct { MbTag t; u32 lower, upper; } __attribute__((packed)) MbMem;

bool boot_info_parse(u32 magic, const void *mbi) {
    memset(&g_boot, 0, sizeof g_boot);
    if (magic != MB2_BOOT_MAGIC || !mbi) return false;
    u32 total = *(const u32 *)mbi;
    const u8 *p = (const u8 *)mbi + 8, *end = (const u8 *)mbi + total;
    while (p + sizeof(MbTag) <= end) {
        const MbTag *t = (const MbTag *)p;
        if (t->type == 0) break;
        if (t->type == 4 && t->size >= sizeof(MbMem)) {
            const MbMem *m = (const MbMem *)t; g_boot.mem_kb = m->lower + m->upper;
        } else if (t->type == 8 && t->size >= 31) {
            const MbFb *f = (const MbFb *)t;
            if ((f->addr >> 32) == 0) {
                g_boot.fb_addr = (u32)f->addr; g_boot.fb_pitch = f->pitch;
                g_boot.fb_w = f->width; g_boot.fb_h = f->height;
                g_boot.fb_bpp = f->bpp; g_boot.fb_type = f->fbtype;
                if (f->fbtype == 1 && t->size >= sizeof(MbFb)) {
                    g_boot.r_pos = f->r_pos; g_boot.g_pos = f->g_pos; g_boot.b_pos = f->b_pos;
                } else { g_boot.r_pos = 16; g_boot.g_pos = 8; g_boot.b_pos = 0; }
                g_boot.has_fb = (f->fbtype == 1 && f->bpp == 32 && f->width >= 800 && f->height >= 600);
            }
        }
        p += (t->size + 7) & ~7u;
    }
    return true;
}
