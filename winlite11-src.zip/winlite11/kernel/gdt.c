#include "cpu.h"
typedef struct { u16 limit_lo, base_lo; u8 base_mid, access, gran, base_hi; } __attribute__((packed)) GdtEntry;
typedef struct { u16 limit; u32 base; } __attribute__((packed)) GdtPtr;
extern void gdt_flush(GdtPtr *p);
static GdtEntry gdt[3]; static GdtPtr gp;
static void set(int i, u32 base, u32 lim, u8 acc, u8 gran) {
    gdt[i] = (GdtEntry){ lim & 0xFFFF, base & 0xFFFF, (base >> 16) & 0xFF, acc, ((lim >> 16) & 0x0F) | (gran & 0xF0), (base >> 24) & 0xFF };
}
void gdt_init(void) {
    set(0, 0, 0, 0, 0);
    set(1, 0, 0xFFFFF, 0x9A, 0xCF);   /* 0x08: ring0 code, 4 GiB flat */
    set(2, 0, 0xFFFFF, 0x92, 0xCF);   /* 0x10: ring0 data */
    gp.limit = sizeof gdt - 1; gp.base = (u32)gdt;
    gdt_flush(&gp);
}
