#include "desktop.h"
#include "cpu.h"
#include "../gui/shell.h"
#include "../drivers/drivers.h"

static int mx = 512, my = 384; static u8 prev_buttons;

void desktop_step(void) {
    KeyEvent ke;
    while (input_pop_key(&ke)) { shell_key(&ke); ui_invalidate(); }
    MouseEvent me;
    while (input_pop_mouse(&me)) {
        mx += me.dx; my += me.dy;
        if (mx < 0) mx = 0;
        if (my < 0) my = 0;
        if (mx > gfx_w - 1) mx = gfx_w - 1;
        if (my > gfx_h - 1) my = gfx_h - 1;
        g_mx = mx; g_my = my;
        bool l = me.buttons & 1, pl = prev_buttons & 1;
        if (l && !pl) shell_mouse(EV_DOWN, mx, my);
        else if (!l && pl) shell_mouse(EV_UP, mx, my);
        else if (l) shell_mouse(EV_DRAG, mx, my);
        prev_buttons = me.buttons;
        ui_invalidate();
    }
    shell_tick();
    if (g_dirty) {
        g_dirty = false;
        shell_render();
        gfx_cursor_move(mx, my);
        gfx_flip();
    } else gfx_cursor_move(mx, my);
}
