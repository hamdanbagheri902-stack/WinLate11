#include "cpu.h"
#include "klib.h"
#include "../gui/gfx.h"
#include "../drivers/drivers.h"
void kpanic(const char *msg, const Regs *r) {
    cli();
    char buf[320];
    if (r) ksnprintf(buf, sizeof buf, "%s (exception %u, error code 0x%x)\n\nEIP=0x%08x  CS=0x%x  EFLAGS=0x%x\nEAX=0x%08x EBX=0x%08x ECX=0x%08x EDX=0x%08x\nESI=0x%08x EDI=0x%08x EBP=0x%08x ESP=0x%08x\n\nPlease restart the virtual machine.",
        msg, r->int_no, r->err_code, r->eip, r->cs, r->eflags, r->eax, r->ebx, r->ecx, r->edx, r->esi, r->edi, r->ebp, r->esp);
    else ksnprintf(buf, sizeof buf, "%s\n\nPlease restart the virtual machine.", msg);
    if (gfx_ready) gfx_panic_screen(buf); else vga_show(buf);
    cpu_halt_forever();
}
