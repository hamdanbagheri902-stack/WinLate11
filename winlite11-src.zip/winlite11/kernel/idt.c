#include "cpu.h"
#include "../drivers/drivers.h"
typedef struct { u16 lo, sel; u8 zero, flags; u16 hi; } __attribute__((packed)) IdtEntry;
typedef struct { u16 limit; u32 base; } __attribute__((packed)) IdtPtr;
extern void idt_flush(IdtPtr *p);
extern u32 isr_stub_table[48];
static IdtEntry idt[256]; static IdtPtr ip;
static irq_handler_t handlers[16];

void irq_install(int irq, irq_handler_t h) { handlers[irq] = h; }

void idt_init(void) {
    for (int i = 0; i < 48; i++) {
        u32 a = isr_stub_table[i];
        idt[i] = (IdtEntry){ a & 0xFFFF, 0x08, 0, 0x8E, a >> 16 };
    }
    ip.limit = sizeof idt - 1; ip.base = (u32)idt;
    idt_flush(&ip);
}

static const char *exc_names[] = { "Divide error", "Debug", "NMI", "Breakpoint", "Overflow", "Bound range", "Invalid opcode",
    "Device not available", "Double fault", "Coprocessor overrun", "Invalid TSS", "Segment not present", "Stack fault",
    "General protection fault", "Page fault", "Reserved", "x87 FP error", "Alignment check", "Machine check", "SIMD FP error" };

void isr_dispatch(Regs *r) {
    if (r->int_no < 32) {
        kpanic(r->int_no < 20 ? exc_names[r->int_no] : "CPU exception", r);
        return;
    }
    int irq = (int)r->int_no - 32;
    if (!pic_in_service(irq)) { if (irq == 15) pic_eoi(2); return; }   /* spurious */
    if (handlers[irq]) handlers[irq]();
    pic_eoi(irq);
}
