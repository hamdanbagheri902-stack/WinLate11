#!/usr/bin/env bash
# Builds winlite11.iso. On Ubuntu/WSL install prerequisites with:
#   sudo apt install build-essential grub-pc-bin grub-common xorriso mtools
set -e
cd "$(dirname "$0")"
missing=0
for t in gcc ld make grub-mkrescue xorriso mformat; do
    command -v $t >/dev/null || { echo "missing tool: $t"; missing=1; }
done
if [ $missing = 1 ]; then
    echo "Install with: sudo apt install build-essential grub-pc-bin grub-common xorriso mtools"; exit 1
fi
[ -d /usr/lib/grub/i386-pc ] || { echo "missing /usr/lib/grub/i386-pc (apt install grub-pc-bin)"; exit 1; }
make clean
make -j"$(nproc)" kernel.elf
python3 tools/check_kernel.py kernel.elf
make winlite11.iso
echo "Built: $(pwd)/winlite11.iso"
