#pragma once
#include "../kernel/types.h"
typedef struct { int year, month, day, hour, min, sec; } DateTime;
void vga_show(const char *msg);
void pic_init(void);  void pic_unmask(int irq);  void pic_eoi(int irq);  bool pic_in_service(int irq);
void pit_init(u32 hz); u32 pit_ticks(void);
void ps2_init(void);
void rtc_read(DateTime *d);
void power_shutdown(void); void power_restart(void); void cpu_halt_forever(void);
typedef void (*irq_handler_t)(void);
void irq_install(int irq, irq_handler_t h);
