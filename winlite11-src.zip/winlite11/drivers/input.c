#include "input.h"
#define QN 256
static KeyEvent kq[QN];  static volatile u32 kh, kt;
static MouseEvent mq[QN]; static volatile u32 mh, mt;

void input_push_key(int key, u8 mods) {
    if (kh - kt >= QN) return;
    kq[kh % QN] = (KeyEvent){ key, mods }; __asm__ volatile("" ::: "memory"); kh++;
}
bool input_pop_key(KeyEvent *e) {
    if (kt == kh) return false;
    *e = kq[kt % QN]; __asm__ volatile("" ::: "memory"); kt++; return true;
}
void input_push_mouse(int dx, int dy, u8 b) {
    if (mh - mt >= QN) return;
    mq[mh % QN] = (MouseEvent){ dx, dy, b }; __asm__ volatile("" ::: "memory"); mh++;
}
bool input_pop_mouse(MouseEvent *e) {
    if (mt == mh) return false;
    *e = mq[mt % QN]; __asm__ volatile("" ::: "memory"); mt++; return true;
}
