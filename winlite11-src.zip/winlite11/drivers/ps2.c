/* i8042 controller init and IRQ1/IRQ12 service */
#include "ports.h"
#include "input.h"
#include "drivers.h"

static void wait_write(void) { for (int i = 0; i < 200000; i++) if (!(inb(0x64) & 2)) return; }
static int  read_data(void)  { for (int i = 0; i < 200000; i++) if (inb(0x64) & 1) return inb(0x60); return -1; }
static void ctl(u8 c)  { wait_write(); outb(0x64, c); }
static void dat(u8 d)  { wait_write(); outb(0x60, d); }
static void mouse_cmd(u8 c) { ctl(0xD4); dat(c); read_data(); }

static void ps2_service(void) {
    for (int n = 0; n < 32; n++) {
        u8 st = inb(0x64);
        if (!(st & 1)) break;
        u8 b = inb(0x60);
        if (st & 0x20) mouse_feed_byte(b); else kbd_process_scancode(b);
    }
}
static void irq1(void)  { ps2_service(); }
static void irq12(void) { ps2_service(); }

void ps2_init(void) {
    ctl(0xAD); ctl(0xA7);                          /* disable both ports */
    for (int i = 0; i < 64 && (inb(0x64) & 1); i++) inb(0x60);   /* flush */
    ctl(0x20); int cfg = read_data(); if (cfg < 0) cfg = 0;
    cfg |= 0x03 | 0x40;                            /* IRQ1+IRQ12 on, translate to set 1 */
    cfg &= ~0x30;                                  /* clocks on */
    ctl(0x60); dat((u8)cfg);
    ctl(0xAE); ctl(0xA8);                          /* enable ports */
    dat(0xF4); read_data();                        /* keyboard: enable scanning */
    mouse_cmd(0xF6);                               /* mouse: defaults */
    mouse_cmd(0xF4);                               /* mouse: enable streaming */
    for (int i = 0; i < 64 && (inb(0x64) & 1); i++) inb(0x60);
    irq_install(1, irq1); irq_install(12, irq12);
    pic_unmask(1); pic_unmask(2); pic_unmask(12);
}
