#pragma once
#include "../kernel/types.h"
/* Key codes: ASCII for printable keys + these. Ctrl+letter arrives as the lowercase letter with MOD_CTRL. */
enum { KEY_BACKSPACE = 8, KEY_TAB = 9, KEY_ENTER = 10, KEY_ESC = 27, KEY_DELETE = 127,
       KEY_UP = 0x100, KEY_DOWN, KEY_LEFT, KEY_RIGHT, KEY_HOME, KEY_END, KEY_PGUP, KEY_PGDN, KEY_INSERT, KEY_F2, KEY_F4, KEY_SUPER };
enum { MOD_SHIFT = 1, MOD_CTRL = 2, MOD_ALT = 4 };
typedef struct { int key; u8 mods; } KeyEvent;
typedef struct { int dx, dy; u8 buttons; } MouseEvent;   /* buttons: 1=left 2=right 4=middle; dy: screen coordinates (down is +) */

void input_push_key(int key, u8 mods);
bool input_pop_key(KeyEvent *e);
void input_push_mouse(int dx, int dy, u8 buttons);
bool input_pop_mouse(MouseEvent *e);

/* decoders (pure; used by the IRQ handler and by host tests) */
void kbd_process_scancode(u8 sc);
void mouse_feed_byte(u8 b);
