/* PS/2 keyboard: scancode set 1 (controller translation on) -> KeyEvent */
#include "input.h"

static const char lower[] = "\0\033" "1234567890-=\b\t" "qwertyuiop[]\n\0" "asdfghjkl;'`\0\\" "zxcvbnm,./\0*\0 ";
static const char upper[] = "\0\033" "!@#$%^&*()_+\b\t" "QWERTYUIOP{}\n\0" "ASDFGHJKL:\"~\0|" "ZXCVBNM<>?\0*\0 ";

static u8 shift, ctrl, alt, caps, ext;

void kbd_process_scancode(u8 sc) {
    if (sc == 0xE0) { ext = 1; return; }
    int up = sc & 0x80; u8 code = sc & 0x7F;
    int e = ext; ext = 0;
    if (!e && (code == 0x2A || code == 0x36)) { shift = !up; return; }
    if (code == 0x1D) { ctrl = !up; return; }
    if (code == 0x38) { alt = !up; return; }
    if (up) return;
    if (!e && code == 0x3A) { caps = !caps; return; }
    u8 mods = (shift ? MOD_SHIFT : 0) | (ctrl ? MOD_CTRL : 0) | (alt ? MOD_ALT : 0);
    int key = 0;
    if (e) {
        switch (code) {
        case 0x48: key = KEY_UP; break;    case 0x50: key = KEY_DOWN; break;
        case 0x4B: key = KEY_LEFT; break;  case 0x4D: key = KEY_RIGHT; break;
        case 0x47: key = KEY_HOME; break;  case 0x4F: key = KEY_END; break;
        case 0x49: key = KEY_PGUP; break;  case 0x51: key = KEY_PGDN; break;
        case 0x53: key = KEY_DELETE; break; case 0x52: key = KEY_INSERT; break;
        case 0x1C: key = KEY_ENTER; break; case 0x35: key = '/'; break;
        case 0x5B: case 0x5C: key = KEY_SUPER; break;
        }
    } else if (code == 0x3C) key = KEY_F2;
    else if (code == 0x3E) key = KEY_F4;
    else if (code < sizeof(lower) - 1) {
        char c = shift ? upper[code] : lower[code];
        int letter = (lower[code] >= 'a' && lower[code] <= 'z');
        if (letter && caps) c = shift ? lower[code] : upper[code];
        if (ctrl && letter) c = lower[code];
        key = (u8)c;
    }
    if (key) input_push_key(key, mods);
}
