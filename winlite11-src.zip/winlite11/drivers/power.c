#include "ports.h"
#include "drivers.h"
extern void cpu_triple_fault(void);
void power_shutdown(void) {
    outw(0x4004, 0x3400);    /* VirtualBox ACPI PM1a_CNT (SLP_TYPa=5, SLP_EN) */
    outw(0x604, 0x2000);     /* QEMU / newer Bochs */
    outw(0xB004, 0x2000);    /* older Bochs / QEMU */
    /* If we get here the hypervisor ignored us: caller shows "safe to turn off" and halts. */
}
void power_restart(void) {
    for (int i = 0; i < 100000 && (inb(0x64) & 2); i++) {}
    outb(0x64, 0xFE);        /* pulse CPU reset line via keyboard controller */
    for (volatile int i = 0; i < 1000000; i++) {}
    cpu_triple_fault();
}
void cpu_halt_forever(void) { for (;;) __asm__ volatile("cli; hlt"); }
