#include "ports.h"
#include "drivers.h"
static volatile u32 ticks;
static void irq0(void) { ticks++; }
void pit_init(u32 hz) {
    u32 div = 1193182 / hz;
    outb(0x43, 0x36); outb(0x40, div & 0xFF); outb(0x40, (div >> 8) & 0xFF);
    irq_install(0, irq0); pic_unmask(0);
}
u32 pit_ticks(void) { return ticks; }
