/* Fallback: VGA text mode message, used if GRUB could not give us a framebuffer. */
#include "../kernel/klib.h"
#include "drivers.h"
void vga_show(const char *msg) {
    volatile u16 *vm = (volatile u16 *)0xB8000;
    for (int i = 0; i < 80 * 25; i++) vm[i] = 0x1F20;
    int r = 1, c = 2;
    for (; *msg; msg++) {
        if (*msg == '\n' || c >= 78) { r++; c = 2; if (*msg == '\n') continue; }
        vm[r * 80 + c++] = 0x1F00 | (u8)*msg;
    }
}
