/* PS/2 mouse: standard 3-byte packets */
#include "input.h"
static u8 pkt[3]; static int idx;

void mouse_feed_byte(u8 b) {
    if (idx == 0 && !(b & 0x08)) return;          /* out of sync: first byte always has bit 3 set */
    pkt[idx++] = b;
    if (idx < 3) return;
    idx = 0;
    if (pkt[0] & 0xC0) return;                    /* overflow: drop */
    int dx = (int)pkt[1] - (int)((pkt[0] << 4) & 0x100);
    int dy = (int)pkt[2] - (int)((pkt[0] << 3) & 0x100);
    input_push_mouse(dx, -dy, pkt[0] & 7);
}
