#include "ports.h"
#include "drivers.h"
static u8 cmos(u8 r) { outb(0x70, r); return inb(0x71); }
static void raw(DateTime *d, u8 *hr_raw, u8 *regB) {
    while (cmos(0x0A) & 0x80) {}
    d->sec = cmos(0); d->min = cmos(2); *hr_raw = cmos(4);
    d->day = cmos(7); d->month = cmos(8); d->year = cmos(9); *regB = cmos(0x0B);
}
void rtc_read(DateTime *o) {
    DateTime a, b; u8 ha, hb, rb;
    raw(&a, &ha, &rb);
    for (int i = 0; i < 4; i++) {                     /* re-read until stable */
        raw(&b, &hb, &rb);
        if (a.sec == b.sec && a.min == b.min && ha == hb && a.day == b.day) break;
        a = b; ha = hb;
    }
    int pm = hb & 0x80; hb &= 0x7F;
    #define BCD(x) (((x) & 0x0F) + ((x) >> 4) * 10)
    if (!(rb & 4)) { b.sec = BCD(b.sec); b.min = BCD(b.min); hb = BCD(hb); b.day = BCD(b.day); b.month = BCD(b.month); b.year = BCD(b.year); }
    if (!(rb & 2)) { if (hb == 12) hb = 0; if (pm) hb += 12; }
    b.hour = hb; b.year += 2000;
    if (b.month < 1 || b.month > 12) b.month = 1;
    if (b.day < 1 || b.day > 31) b.day = 1;
    *o = b;
}
