#include "ports.h"
#include "drivers.h"
void pic_init(void) {
    outb(0x20, 0x11); io_wait(); outb(0xA0, 0x11); io_wait();
    outb(0x21, 0x20); io_wait(); outb(0xA1, 0x28); io_wait();
    outb(0x21, 0x04); io_wait(); outb(0xA1, 0x02); io_wait();
    outb(0x21, 0x01); io_wait(); outb(0xA1, 0x01); io_wait();
    outb(0x21, 0xFF); outb(0xA1, 0xFF);
}
void pic_unmask(int irq) {
    u16 port = irq < 8 ? 0x21 : 0xA1; int bit = irq & 7;
    outb(port, inb(port) & ~(1 << bit));
}
void pic_eoi(int irq) { if (irq >= 8) outb(0xA0, 0x20); outb(0x20, 0x20); }
/* returns true if the IRQ is really in service (filters spurious IRQ7/15) */
bool pic_in_service(int irq) {
    if (irq == 7)  { outb(0x20, 0x0B); return inb(0x20) & 0x80; }
    if (irq == 15) { outb(0xA0, 0x0B); return inb(0xA0) & 0x80; }
    return true;
}
