#include "theme.h"
#include "../kernel/klib.h"

Theme T;
const u32 ACCENTS[ACCENT_COUNT] = { 0xFF0067C0, 0xFF0F8B8D, 0xFF2E8B57, 0xFFD9730D, 0xFFC2185B, 0xFF7A4DCC };
const char *WALL_NAMES[WALL_COUNT] = { "Bloom", "Mint", "Sunset", "Lavender", "Slate", "Rose" };

void theme_apply(bool dark, int accent) {
    T.dark = dark; T.accent_idx = accent; T.accent = ACCENTS[accent]; T.accent_text = 0xFFFFFFFF; T.close_red = 0xFFC42B1C;
    if (!dark) {
        T.win = 0xFFF3F3F3; T.card = 0xFFFFFFFF; T.card_alt = 0xFFF9F9F9; T.text = 0xFF1B1B1B; T.dim = 0xFF5F5F5F;
        T.border = 0xFFD2D2D2; T.taskbar = 0xE8EEEEEE; T.menu = 0xF4F3F3F3; T.hover = 0x14000000; T.press = 0x0A000000;
    } else {
        T.win = 0xFF202020; T.card = 0xFF2C2C2C; T.card_alt = 0xFF262626; T.text = 0xFFFFFFFF; T.dim = 0xFFA6A6A6;
        T.border = 0xFF404040; T.taskbar = 0xE8202020; T.menu = 0xF4262626; T.hover = 0x1CFFFFFF; T.press = 0x10FFFFFF;
    }
}
void theme_init(void) { T.wall_idx = 0; theme_apply(false, 0); }

/* ---- procedural wallpaper: soft gradient with glowing blobs ---- */
typedef struct { u32 top, bot; u32 blob[3]; } WallPreset;
static const WallPreset presets[WALL_COUNT] = {
    { 0xB9D8FA, 0xE6F0FC, { 0x3D8BFD, 0x7FD1F5, 0xA48CF2 } },
    { 0xCFEFE4, 0xEAF8F2, { 0x2FBF9B, 0x8EE3C4, 0x6CB7E8 } },
    { 0xFBD9C2, 0xFDEBDD, { 0xF2864B, 0xF7B267, 0xE56B8F } },
    { 0xDCD3F5, 0xF0EBFB, { 0x8A6FE0, 0xC4A9F2, 0x7BA6F0 } },
    { 0xC9D2DC, 0xE4E9EE, { 0x5C7287, 0x9FB2C4, 0x7A8FD0 } },
    { 0xF8D2DD, 0xFCE9EE, { 0xE0527E, 0xF4A3BA, 0xF0A070 } },
};
static u32 *wall;
const u32 *wall_buffer(void) { return wall; }

static int wall_row, wall_preset; static bool wall_dark;
void wall_preset_info(int idx, u32 *top, u32 *bot, u32 *blob) { *top = presets[idx].top; *bot = presets[idx].bot; *blob = presets[idx].blob[0]; }

void wall_begin(int idx, bool dark) {
    if (!wall) wall = kmalloc((size_t)gfx_w * gfx_h * 4);
    wall_row = 0; wall_preset = idx; wall_dark = dark; T.wall_idx = idx;
}
bool wall_step(int rows) {
    if (!wall) return true;
    const WallPreset *p = &presets[wall_preset];
    static const int bx[3] = { 260, 780, 520 }, by[3] = { 620, 200, 420 }, br[3] = { 520, 460, 360 }, bs[3] = { 230, 200, 150 };
    int sx = gfx_w, sy = gfx_h;
    for (; rows > 0 && wall_row < gfx_h; rows--, wall_row++) {
        int y = wall_row;
        for (int x = 0; x < gfx_w; x++) {
            int t = (y * 256 / sy * 3 + x * 256 / sx) / 4;
            u32 c = gfx_lerp(p->top, p->bot, t);
            for (int k = 0; k < 3; k++) {
                int dx = x * 1024 / sx - bx[k], dy = y * 768 / sy - by[k];
                u32 d2 = (u32)(dx * dx + dy * dy), r2 = (u32)(br[k] * br[k]);
                if (d2 >= r2) continue;
                u32 w = 256 - d2 * 256 / r2; w = (w * w) >> 8; w = (w * bs[k]) >> 8;
                c = gfx_lerp(c, p->blob[k], (int)w);
            }
            if (wall_dark) {
                u32 r = (((c >> 16) & 255) * 70) >> 8, g = (((c >> 8) & 255) * 78) >> 8, b = ((c & 255) * 96) >> 8;
                c = (r << 16) | (g << 8) | b;
            }
            wall[y * gfx_w + x] = c & 0xFFFFFF;
        }
    }
    return wall_row >= gfx_h;
}
void wall_render(int idx, bool dark) { wall_begin(idx, dark); while (!wall_step(64)) {} }
