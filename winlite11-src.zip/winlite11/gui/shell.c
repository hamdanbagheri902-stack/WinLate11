/* Desktop shell: wallpaper, desktop icons, centered taskbar, Start menu (with search), quick settings, tray, power screens. */
#include "shell.h"
#include "../apps/apps.h"
#include "../kernel/klib.h"
#include "../drivers/drivers.h"

/* ---------------- state ---------------- */
static bool start_open, quick_open, power_pop;
static char query[32]; static int qlen;
static int power_state; static u32 power_t0; static bool power_fired;
static int sel_icon = -1, last_icon = -1; static u32 last_icon_t;
static DateTime now_dt; static bool have_time; static u32 last_tick_sec, last_tick_blink;

static bool overlay_open(void) { return start_open || quick_open || power_pop; }
void shell_init(void) { wm_overlay_open = overlay_open; rtc_read(&now_dt); have_time = true; }
int shell_power_state(void) { return power_state; }

void shell_set_theme(int dark, int accent, int wall) {
    int nd = dark < 0 ? T.dark : dark, na = accent < 0 ? T.accent_idx : accent, nw = wall < 0 ? T.wall_idx : wall;
    bool rewall = (nd != (int)T.dark) || (nw != T.wall_idx);
    theme_apply(nd != 0, na);
    if (rewall) wall_render(nw, nd != 0);
    ui_invalidate();
}
void shell_power(int action) {
    power_state = action; power_t0 = pit_ticks(); power_fired = false;
    start_open = quick_open = power_pop = false; ui_invalidate();
}

/* ---------------- desktop icons ---------------- */
typedef struct { const char *label; int app; const char *path; } DeskIcon;
static const DeskIcon DICONS[] = {
    { "This PC", APP_EXPLORER, "/" }, { "Documents", APP_EXPLORER, "/Documents" },
    { "Notepad", APP_NOTEPAD, 0 }, { "Terminal", APP_TERMINAL, 0 } };
#define NICONS 4
static void icon_rect(int i, int *x, int *y) { *x = 10; *y = 10 + i * 96; }
static void launch_icon(int i) {
    if (DICONS[i].app == APP_EXPLORER) explorer_open(DICONS[i].path); else app_launch(DICONS[i].app);
}
static void draw_desktop(void) {
    const u32 *wp = wall_buffer();
    if (wp) gfx_blit(wp); else gfx_fill(0, 0, gfx_w, gfx_h, RGB(0xB9, 0xD8, 0xFA));
    for (int i = 0; i < NICONS; i++) {
        int x, y; icon_rect(i, &x, &y);
        if (i == sel_icon) { gfx_rrect(x, y, 84, 88, 6, ARGB(56, 255, 255, 255)); gfx_rrect_border(x, y, 84, 88, 6, ARGB(110, 255, 255, 255)); }
        if (DICONS[i].app == APP_EXPLORER && DICONS[i].path[1]) ui_folder_icon(x + 18, y + 8, 48);
        else ui_app_icon(DICONS[i].app, x + 18, y + 8, 48);
        int tx = x + (84 - gfx_text_w(DICONS[i].label)) / 2;
        gfx_text(tx + 1, y + 63, DICONS[i].label, ARGB(170, 0, 0, 0));
        gfx_text(tx, y + 62, DICONS[i].label, 0xFFFFFFFF);
    }
}

/* ---------------- taskbar ---------------- */
static int tb_y(void) { return gfx_h - TASKBAR_H; }
static int btn_x(int i) { return (gfx_w - 6 * 44) / 2 + i * 44; }
static void tray_geom(int *chev, int *pill, int *clock) { *clock = gfx_w - 12 - 84; *pill = *clock - 4 - 76; *chev = *pill - 4 - 28; }

static void glyph_wifi(int x, int y, u32 c) { for (int i = 0; i < 4; i++) gfx_fill(x + i * 4, y + 12 - i * 3, 3, 3 + i * 3, c); }
static void glyph_volume(int x, int y, u32 c) {
    gfx_fill(x, y + 4, 4, 6, c);
    gfx_line(x + 4, y + 4, x + 9, y, 1, c); gfx_line(x + 9, y, x + 9, y + 14, 1, c); gfx_line(x + 9, y + 14, x + 4, y + 10, 1, c);
    gfx_line(x + 12, y + 4, x + 14, y + 7, 1, c); gfx_line(x + 14, y + 7, x + 12, y + 10, 1, c);
}
static void format_time(char *t, size_t nt, char *d, size_t nd) {
    int h = now_dt.hour % 12; if (h == 0) h = 12;
    ksnprintf(t, nt, "%d:%02d %s", h, now_dt.min, now_dt.hour >= 12 ? "PM" : "AM");
    ksnprintf(d, nd, "%d/%d/%d", now_dt.month, now_dt.day, now_dt.year);
}
static void draw_taskbar(void) {
    int y = tb_y();
    gfx_fill(0, y, gfx_w, TASKBAR_H, T.taskbar);
    gfx_hline(0, y, gfx_w, T.dark ? ARGB(70, 255, 255, 255) : ARGB(60, 0, 0, 0));
    Window *top = wm_top();
    for (int i = 0; i < 6; i++) {
        int x = btn_x(i), by = y + 4;
        bool hot = pt_in(x, by, 40, 40, g_mx, g_my) && !(start_open && pt_in((gfx_w - 560) / 2, 0, 560, tb_y(), g_mx, g_my));
        int app = i - 1; Window *w = i ? wm_find_app(app) : 0;
        bool active = i == 0 ? start_open : (w && w == top);
        if (active || hot) gfx_rrect(x, by, 40, 40, 6, active ? T.hover : T.hover);
        if (i == 0) ui_logo(x + 9, by + 9, 22); else ui_app_icon(app, x + 8, by + 8, 24);
        if (i && w) gfx_rrect(x + (active ? 12 : 17), y + TASKBAR_H - 7, active ? 16 : 6, 3, 1, active ? T.accent : T.dim);
    }
    /* tray */
    int chev, pill, clk; tray_geom(&chev, &pill, &clk);
    u32 ic = T.text;
    if (pt_in(chev, y + 6, 28, 36, g_mx, g_my)) gfx_rrect(chev, y + 6, 28, 36, 6, T.hover);
    gfx_line(chev + 9, y + 26, chev + 14, y + 21, 1, ic); gfx_line(chev + 14, y + 21, chev + 19, y + 26, 1, ic);
    if (quick_open || pt_in(pill, y + 6, 76, 36, g_mx, g_my)) gfx_rrect(pill, y + 6, 76, 36, 6, T.hover);
    glyph_wifi(pill + 14, y + 16, ic); glyph_volume(pill + 44, y + 17, ic);
    if (pt_in(clk, y + 6, 84, 36, g_mx, g_my)) gfx_rrect(clk, y + 6, 84, 36, 6, T.hover);
    char t[16], d[16]; format_time(t, sizeof t, d, sizeof d);
    gfx_text_right(clk + 80, y + 8, t, T.text); gfx_text_right(clk + 80, y + 24, d, T.text);
    gfx_vline(gfx_w - 6, y + 6, 36, T.dark ? ARGB(40, 255, 255, 255) : ARGB(40, 0, 0, 0));   /* show-desktop sliver */
}

/* ---------------- Start menu ---------------- */
#define SM_W 560
static int sm_h(void) { int h = gfx_h - TASKBAR_H - 24; return h > 600 ? 600 : h; }
static void sm_geom(int *x, int *y, int *w, int *h) { *w = SM_W; *h = sm_h(); *x = (gfx_w - SM_W) / 2; *y = tb_y() - 12 - *h; }

typedef struct { int app; FsNode *node; char label[40]; char sub[48]; } Result;
static int nres;
static Result res[8];
static void add_result(int app, FsNode *n, const char *label, const char *sub) {
    if (nres >= 8) return;
    Result *r = &res[nres++]; r->app = app; r->node = n;
    kstrlcpy(r->label, label, sizeof r->label); kstrlcpy(r->sub, sub, sizeof r->sub);
}
static void walk(FsNode *n) {
    for (FsNode *c = n->child; c && nres < 8; c = c->next) {
        if (c->is_dir) walk(c);
        else if (kstrcasecontains(c->name, query)) { char p[96]; fs_path(c, p, sizeof p); add_result(-1, c, c->name, p); }
    }
}
static void collect(void) {
    nres = 0;
    if (!qlen) {
        FsNode *docs = fs_lookup(0, "/Documents");
        if (docs) for (FsNode *c = docs->child; c && nres < 5; c = c->next)
            if (!c->is_dir) { char p[96]; fs_path(c, p, sizeof p); add_result(-1, c, c->name, p); }
        return;
    }
    for (int i = 0; i < APP_COUNT; i++) if (kstrcasecontains(APP_NAMES[i], query)) add_result(i, 0, APP_NAMES[i], "App");
    walk(fs_root());
}
static void open_result(int i) {
    if (i < 0 || i >= nres) return;
    Result r = res[i];
    start_open = false; power_pop = false;
    if (r.app >= 0) app_launch(r.app);
    else if (fs_valid(r.node)) { char p[96]; fs_path(r.node, p, sizeof p); notepad_open(p); }
}
static void toggle_start(void) { start_open = !start_open; quick_open = false; power_pop = false; query[0] = 0; qlen = 0; ui_invalidate(); }
void shell_toggle_start(void) { toggle_start(); }
bool shell_start_visible(void) { return start_open; }

static const struct { int app; const char *label; const char *path; } TILES[6] = {
    { APP_EXPLORER, "File Explorer", 0 }, { APP_NOTEPAD, "Notepad", 0 }, { APP_CALC, "Calculator", 0 },
    { APP_TERMINAL, "Terminal", 0 }, { APP_SETTINGS, "Settings", 0 }, { APP_EXPLORER, "Documents", "/Documents" } };

static void tile_rect(int i, int x, int y, int *tx, int *ty, int *tw, int *th) {
    *tw = (SM_W - 48 - 20) / 3; *th = 64; *tx = x + 24 + (i % 3) * (*tw + 10); *ty = y + 100 + (i / 3) * 74;
}
static void power_btn_rect(int *bx, int *by) { int x, y, w, h; sm_geom(&x, &y, &w, &h); *bx = x + w - 24 - 36; *by = y + h - 64 + 14; }
static void power_pop_rect(int *px, int *py) { int bx, by; power_btn_rect(&bx, &by); *px = bx + 36 - 150; *py = by - 8 - 80; }

static void draw_start(void) {
    int x, y, w, h; sm_geom(&x, &y, &w, &h);
    gfx_shadow(x, y, w, h, 12, 16, 90);
    gfx_rrect(x, y, w, h, 12, T.menu); gfx_rrect_border(x, y, w, h, 12, T.border);
    /* search box */
    gfx_rrect(x + 24, y + 20, w - 48, 36, 18, T.card); gfx_rrect_border(x + 24, y + 20, w - 48, 36, 18, qlen ? T.accent : T.border);
    gfx_rrect_border(x + 38, y + 29, 12, 12, 6, T.dim); gfx_line(x + 47, y + 39, x + 52, y + 44, 1, T.dim);
    if (qlen) { int tx = gfx_text(x + 64, y + 28, query, T.text); if (((pit_ticks() / 50) & 1) == 0) gfx_fill(tx, y + 28, 2, 16, T.accent); }
    else gfx_text(x + 64, y + 28, "Type here to search apps and files", T.dim);
    collect();
    if (!qlen) {
        gfx_text_bold(x + 28, y + 74, "Pinned", T.text);
        for (int i = 0; i < 6; i++) {
            int tx, ty, tw, th; tile_rect(i, x, y, &tx, &ty, &tw, &th);
            gfx_rrect(tx, ty, tw, th, 8, T.card); gfx_rrect_border(tx, ty, tw, th, 8, T.border);
            if (pt_in(tx, ty, tw, th, g_mx, g_my) && !power_pop) gfx_rrect(tx, ty, tw, th, 8, T.hover);
            if (i == 5) ui_folder_icon(tx + 14, ty + 16, 32); else ui_app_icon(TILES[i].app, tx + 14, ty + 16, 32);
            gfx_text_clipped(tx + 54, ty + 24, tw - 58, TILES[i].label, T.text);
        }
        gfx_text_bold(x + 28, y + 256, "Recommended", T.text);
    } else gfx_text_bold(x + 28, y + 74, nres ? "Results" : "No results found", T.text);
    int ry0 = qlen ? y + 104 : y + 280;
    for (int i = 0; i < nres && ry0 + i * 44 + 40 <= y + h - 64; i++) {
        int rx = x + 20, ry = ry0 + i * 44;
        if (pt_in(rx, ry, w - 40, 40, g_mx, g_my) && !power_pop) gfx_rrect(rx, ry, w - 40, 40, 6, T.hover);
        else if (qlen && i == 0) gfx_rrect(rx, ry, w - 40, 40, 6, COL_ALPHA(T.accent, 40));
        if (res[i].app >= 0) ui_app_icon(res[i].app, rx + 10, ry + 6, 28); else ui_file_icon(rx + 10, ry + 6, 28);
        gfx_text_clipped(rx + 50, ry + 2, w - 100, res[i].label, T.text);
        gfx_text_clipped(rx + 50, ry + 21, w - 100, res[i].sub, T.dim);
    }
    /* footer */
    int fy = y + h - 64;
    gfx_fill(x + 1, fy, w - 2, 1, T.border);
    gfx_circle(x + 48, fy + 32, 16, T.accent); gfx_text_center(x + 32, fy + 24, 32, "W", T.accent_text);
    gfx_text(x + 74, fy + 24, "WinLite User", T.text);
    int bx, by; power_btn_rect(&bx, &by);
    if (power_pop || pt_in(bx, by, 36, 36, g_mx, g_my)) gfx_rrect(bx, by, 36, 36, 6, T.hover);
    gfx_rrect_border(bx + 10, by + 11, 16, 16, 8, T.text); gfx_fill(bx + 17, by + 8, 2, 11, T.text);
    if (power_pop) {
        int px, py; power_pop_rect(&px, &py);
        gfx_shadow(px, py, 150, 80, 8, 10, 80);
        gfx_rrect(px, py, 150, 80, 8, T.card); gfx_rrect_border(px, py, 150, 80, 8, T.border);
        static const char *items[2] = { "Shut down", "Restart" };
        for (int i = 0; i < 2; i++) {
            if (pt_in(px + 4, py + 4 + i * 36, 142, 34, g_mx, g_my)) gfx_rrect(px + 4, py + 4 + i * 36, 142, 34, 6, T.hover);
            gfx_text(px + 18, py + 12 + i * 36, items[i], T.text);
        }
    }
}
static void start_click(int mx, int my) {
    int x, y, w, h; sm_geom(&x, &y, &w, &h);
    if (power_pop) {
        int px, py; power_pop_rect(&px, &py);
        for (int i = 0; i < 2; i++) if (pt_in(px + 4, py + 4 + i * 36, 142, 34, mx, my)) { shell_power(i ? POWER_RESTART : POWER_SHUTDOWN); return; }
    }
    int bx, by; power_btn_rect(&bx, &by);
    if (pt_in(bx, by, 36, 36, mx, my)) { power_pop = !power_pop; return; }
    power_pop = false;
    if (!qlen) {
        for (int i = 0; i < 6; i++) {
            int tx, ty, tw, th; tile_rect(i, x, y, &tx, &ty, &tw, &th);
            if (pt_in(tx, ty, tw, th, mx, my)) { start_open = false; if (TILES[i].path) explorer_open(TILES[i].path); else app_launch(TILES[i].app); return; }
        }
    }
    int ry0 = qlen ? y + 104 : y + 280;
    for (int i = 0; i < nres; i++) if (pt_in(x + 20, ry0 + i * 44, w - 40, 40, mx, my)) { open_result(i); return; }
}

/* ---------------- quick settings ---------------- */
#define QW 312
#define QH 172
static void quick_geom(int *x, int *y) { *x = gfx_w - 12 - QW; *y = tb_y() - 12 - QH; }
static void quick_tile(int i, int x, int y, int *tx, int *ty) { *tx = x + 16 + (i % 2) * 146; *ty = y + 16 + (i / 2) * 76; }
static void draw_quick(void) {
    int x, y; quick_geom(&x, &y);
    gfx_shadow(x, y, QW, QH, 12, 16, 90);
    gfx_rrect(x, y, QW, QH, 12, T.menu); gfx_rrect_border(x, y, QW, QH, 12, T.border);
    static const char *lab[4] = { "Dark mode", "Wallpaper", "Restart", "Shut down" };
    for (int i = 0; i < 4; i++) {
        int tx, ty; quick_tile(i, x, y, &tx, &ty);
        bool on = i == 0 && T.dark;
        gfx_rrect(tx, ty, 134, 64, 8, on ? T.accent : T.card);
        if (!on) gfx_rrect_border(tx, ty, 134, 64, 8, T.border);
        if (pt_in(tx, ty, 134, 64, g_mx, g_my)) gfx_rrect(tx, ty, 134, 64, 8, on ? ARGB(40, 255, 255, 255) : T.hover);
        u32 fg = on ? T.accent_text : T.text;
        gfx_text(tx + 14, ty + 12, lab[i], fg);
        const char *sub = i == 0 ? (T.dark ? "On" : "Off") : i == 1 ? WALL_NAMES[T.wall_idx] : i == 2 ? "Reboot now" : "Power off";
        gfx_text(tx + 14, ty + 34, sub, on ? ARGB(220, 255, 255, 255) : T.dim);
    }
    gfx_text_center(x, y + QH - 26, QW, "WinLite 11", T.dim);
}
static void quick_click(int mx, int my) {
    int x, y; quick_geom(&x, &y);
    for (int i = 0; i < 4; i++) {
        int tx, ty; quick_tile(i, x, y, &tx, &ty);
        if (!pt_in(tx, ty, 134, 64, mx, my)) continue;
        if (i == 0) shell_set_theme(!T.dark, -1, -1);
        else if (i == 1) shell_set_theme(-1, -1, (T.wall_idx + 1) % WALL_COUNT);
        else { quick_open = false; shell_power(i == 2 ? POWER_RESTART : POWER_SHUTDOWN); }
        return;
    }
}

/* ---------------- power screens ---------------- */
static void draw_power(void) {
    for (int y = 0; y < gfx_h; y++) gfx_hline(0, y, gfx_w, gfx_lerp(0xFF0B1020, 0xFF161E36, y * 256 / gfx_h));
    if (power_state == POWER_OFF) {
        gfx_text_center(0, gfx_h / 2 - 8, gfx_w, "It's now safe to turn off your computer.", RGB(220, 226, 240));
        gfx_text_center(0, gfx_h / 2 + 20, gfx_w, "(Your hypervisor did not power the VM off automatically - close the window.)", RGB(130, 140, 165));
        return;
    }
    ui_spinner(gfx_w / 2, gfx_h / 2 - 20, pit_ticks(), 0xFFFFFFFF);
    gfx_text_center(0, gfx_h / 2 + 30, gfx_w, power_state == POWER_RESTART ? "Restarting" : "Shutting down", RGB(235, 240, 250));
}
void shell_render(void) {
    if (power_state) { draw_power(); return; }
    draw_desktop(); wm_draw_all(); draw_taskbar();
    if (quick_open) draw_quick();
    if (start_open) draw_start();
}

/* ---------------- time / power sequencing ---------------- */
void shell_tick(void) {
    u32 t = pit_ticks();
    if (t - last_tick_sec >= 100) {
        last_tick_sec = t; DateTime d; rtc_read(&d);
        if (d.min != now_dt.min || d.hour != now_dt.hour || d.day != now_dt.day) ui_invalidate();
        now_dt = d;
    }
    if (t - last_tick_blink >= 25) { last_tick_blink = t; if (wm_count() || start_open || power_state) ui_invalidate(); }
    if (power_state == POWER_SHUTDOWN && !power_fired && t - power_t0 >= 160) { power_fired = true; power_shutdown(); power_state = POWER_OFF; ui_invalidate(); }
    if (power_state == POWER_RESTART && !power_fired && t - power_t0 >= 160) { power_fired = true; power_restart(); }
}

/* ---------------- input ---------------- */
static void app_button_click(int app) {
    Window *w = wm_find_app(app);
    if (!w) app_launch(app);
    else if (w->minimized) wm_focus(w);
    else if (w == wm_top()) wm_minimize(w);
    else wm_focus(w);
}
void shell_mouse(MouseKind k, int x, int y) {
    if (power_state) return;
    if (k != EV_DOWN) { wm_mouse(k, x, y); return; }
    int sx, sy, sw, sh; sm_geom(&sx, &sy, &sw, &sh);
    int qx, qy; quick_geom(&qx, &qy);
    bool in_start = start_open && pt_in(sx, sy, sw, sh, x, y);
    bool in_pop = false;
    if (start_open && power_pop) { int px, py; power_pop_rect(&px, &py); in_pop = pt_in(px, py, 150, 80, x, y); }
    bool in_quick = quick_open && pt_in(qx, qy, QW, QH, x, y);
    if (in_start || in_pop) { start_click(x, y); ui_invalidate(); return; }
    if (in_quick) { quick_click(x, y); ui_invalidate(); return; }
    bool was_start = start_open, was_quick = quick_open;
    start_open = quick_open = power_pop = false;
    if (was_start || was_quick) ui_invalidate();
    if (y >= tb_y()) {
        int chev, pill, clk; tray_geom(&chev, &pill, &clk);
        if (x >= gfx_w - 6) { wm_minimize_all(); return; }
        if (pt_in(pill, tb_y() + 6, 76, 36, x, y)) { quick_open = !was_quick; ui_invalidate(); return; }
        for (int i = 0; i < 6; i++) if (pt_in(btn_x(i), tb_y() + 4, 40, 40, x, y)) {
            if (i == 0) { if (!was_start) toggle_start(); }
            else app_button_click(i - 1);
            ui_invalidate(); return;
        }
        return;
    }
    if (wm_mouse(k, x, y)) { sel_icon = -1; return; }
    for (int i = 0; i < NICONS; i++) {
        int ix, iy; icon_rect(i, &ix, &iy);
        if (pt_in(ix, iy, 84, 88, x, y)) {
            u32 t = pit_ticks();
            if (last_icon == i && t - last_icon_t < 40) { launch_icon(i); last_icon = -1; }
            else { last_icon = i; last_icon_t = t; }
            sel_icon = i; ui_invalidate(); return;
        }
    }
    sel_icon = -1; ui_invalidate();
}
void shell_key(const KeyEvent *e) {
    if (power_state) return;
    if (e->key == KEY_SUPER || ((e->mods & MOD_CTRL) && e->key == KEY_ESC)) { toggle_start(); return; }
    if (start_open) {
        if (e->key == KEY_ESC) { if (power_pop) power_pop = false; else start_open = false; }
        else if (e->key == KEY_ENTER) { collect(); if (qlen) open_result(0); }
        else if (e->key == KEY_BACKSPACE) { if (qlen) query[--qlen] = 0; }
        else if (e->key >= 32 && e->key < 127 && qlen < 30 && !(e->mods & MOD_CTRL)) { query[qlen++] = (char)e->key; query[qlen] = 0; }
        ui_invalidate(); return;
    }
    if (quick_open && e->key == KEY_ESC) { quick_open = false; ui_invalidate(); return; }
    if ((e->mods & MOD_ALT) && e->key == KEY_F4) { Window *w = wm_top(); if (w) wm_close(w); return; }
    if ((e->mods & MOD_ALT) && e->key == KEY_TAB) { wm_cycle(); return; }
    wm_key(e);
}
