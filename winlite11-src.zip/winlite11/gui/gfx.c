#include "gfx.h"
#include "../kernel/klib.h"

extern const u8 font8x16[256][16];

int gfx_w, gfx_h; bool gfx_ready; u32 *gfx_bb;
static u8 *fb; static int fb_pitch; static bool swap_rb;
static int cl_x0, cl_y0, cl_x1, cl_y1;

void gfx_init(void *fbp, int w, int h, int pitch, bool swap) {
    fb = fbp; gfx_w = w; gfx_h = h; fb_pitch = pitch; swap_rb = swap;
    gfx_bb = kzalloc((size_t)w * h * 4);
    gfx_reset_clip(); gfx_ready = gfx_bb != 0;
}
void gfx_reset_clip(void) { cl_x0 = cl_y0 = 0; cl_x1 = gfx_w; cl_y1 = gfx_h; }
Rect gfx_get_clip(void) { return (Rect){ cl_x0, cl_y0, cl_x1 - cl_x0, cl_y1 - cl_y0 }; }
Rect gfx_set_clip(Rect r) {
    Rect old = gfx_get_clip();
    int x0 = r.x < 0 ? 0 : r.x, y0 = r.y < 0 ? 0 : r.y;
    int x1 = r.x + r.w > gfx_w ? gfx_w : r.x + r.w, y1 = r.y + r.h > gfx_h ? gfx_h : r.y + r.h;
    cl_x0 = x0; cl_y0 = y0; cl_x1 = x1 < x0 ? x0 : x1; cl_y1 = y1 < y0 ? y0 : y1;
    return old;
}

u32 gfx_blend(u32 d, u32 s) {
    u32 a = s >> 24;
    if (a == 255) return s & 0xFFFFFF;
    if (!a) return d;
    u32 ia = 255 - a;
    u32 r = ((((s >> 16) & 255) * a + ((d >> 16) & 255) * ia) + 127) / 255;
    u32 g = ((((s >> 8) & 255) * a + ((d >> 8) & 255) * ia) + 127) / 255;
    u32 b = ((((s) & 255) * a + ((d) & 255) * ia) + 127) / 255;
    return (r << 16) | (g << 8) | b;
}
u32 gfx_lerp(u32 a, u32 b, int t) {
    u32 o = 0;
    for (int sh = 0; sh < 32; sh += 8) {
        int ca = (a >> sh) & 255, cb = (b >> sh) & 255;
        o |= (u32)((ca * (256 - t) + cb * t) >> 8) << sh;
    }
    return o;
}
void gfx_px(int x, int y, u32 c) {
    if (x < cl_x0 || x >= cl_x1 || y < cl_y0 || y >= cl_y1) return;
    u32 *p = &gfx_bb[y * gfx_w + x];
    *p = gfx_blend(*p, c);
}
void gfx_hline(int x, int y, int w, u32 c) {
    if (y < cl_y0 || y >= cl_y1) return;
    int x1 = x + w; if (x < cl_x0) x = cl_x0; if (x1 > cl_x1) x1 = cl_x1;
    if (x1 <= x) return;
    u32 *p = &gfx_bb[y * gfx_w];
    if ((c >> 24) == 255) { u32 v = c & 0xFFFFFF; for (int i = x; i < x1; i++) p[i] = v; }
    else if (c >> 24) for (int i = x; i < x1; i++) p[i] = gfx_blend(p[i], c);
}
void gfx_vline(int x, int y, int h, u32 c) { for (int j = 0; j < h; j++) gfx_px(x, y + j, c); }
void gfx_fill(int x, int y, int w, int h, u32 c) { for (int j = 0; j < h; j++) gfx_hline(x, y + j, w, c); }

/* ---- anti-aliased rounded corners ---- */
static u32 isqrt32(u32 n) {
    u32 r = 0, bit = 1u << 30;
    while (bit > n) bit >>= 2;
    while (bit) { if (n >= r + bit) { n -= r + bit; r = (r >> 1) + bit; } else r >>= 1; bit >>= 2; }
    return r;
}
/* coverage 0..255 of pixel (dx,dy) inside a corner square of radius r (dx,dy measured from the outer corner) */
static int corner_cov(int r, int dx, int dy) {
    int ox = 2 * r - (2 * dx + 1), oy = 2 * r - (2 * dy + 1);
    u32 d = isqrt32((u32)(ox * ox + oy * oy) * 256);
    int cov = ((r * 32 - (int)d + 16) * 255) / 32;
    return cov < 0 ? 0 : cov > 255 ? 255 : cov;
}
static inline u32 scale_a(u32 c, int cov) {
    u32 a = ((c >> 24) * (u32)cov + 127) / 255;
    return (c & 0xFFFFFF) | (a << 24);
}
static void rr_fill(int x, int y, int w, int h, int r, u32 c1, u32 c2) {
    if (w <= 0 || h <= 0) return;
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    if (y >= cl_y1 || y + h <= cl_y0) return;
    for (int j = 0; j < h; j++) {
        int yy = y + j;
        if (yy < cl_y0 || yy >= cl_y1) continue;
        u32 c = c1 == c2 ? c1 : gfx_lerp(c1, c2, h > 1 ? j * 256 / (h - 1) : 0);
        int cj = j < r ? j : (j >= h - r ? h - 1 - j : -1);
        if (cj < 0) { gfx_hline(x, yy, w, c); continue; }
        gfx_hline(x + r, yy, w - 2 * r, c);
        for (int i = 0; i < r; i++) {
            int cov = corner_cov(r, i, cj);
            if (!cov) continue;
            u32 cc = cov == 255 ? c : scale_a(c, cov);
            gfx_px(x + i, yy, cc); gfx_px(x + w - 1 - i, yy, cc);
        }
    }
}
void gfx_rrect(int x, int y, int w, int h, int r, u32 c) { rr_fill(x, y, w, h, r, c, c); }
void gfx_rrect_grad(int x, int y, int w, int h, int r, u32 a, u32 b) { rr_fill(x, y, w, h, r, a, b); }
void gfx_circle(int cx, int cy, int rad, u32 c) { rr_fill(cx - rad, cy - rad, rad * 2, rad * 2, rad, c, c); }

void gfx_rrect_border(int x, int y, int w, int h, int r, u32 c) {
    if (w <= 1 || h <= 1) return;
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    if (r < 2) {
        gfx_hline(x, y, w, c); gfx_hline(x, y + h - 1, w, c);
        for (int j = 1; j < h - 1; j++) { gfx_px(x, y + j, c); gfx_px(x + w - 1, y + j, c); }
        return;
    }
    gfx_hline(x + r, y, w - 2 * r, c); gfx_hline(x + r, y + h - 1, w - 2 * r, c);
    for (int j = r; j < h - r; j++) { gfx_px(x, y + j, c); gfx_px(x + w - 1, y + j, c); }
    for (int j = 0; j < r; j++)
        for (int i = 0; i < r; i++) {
            int co = corner_cov(r, i, j);
            int ci = (i >= 1 && j >= 1) ? corner_cov(r - 1, i - 1, j - 1) : 0;
            int a = co - ci; if (a <= 0) continue;
            u32 cc = scale_a(c, a);
            gfx_px(x + i, y + j, cc); gfx_px(x + w - 1 - i, y + j, cc);
            gfx_px(x + i, y + h - 1 - j, cc); gfx_px(x + w - 1 - i, y + h - 1 - j, cc);
        }
}
void gfx_shadow(int x, int y, int w, int h, int r, int spread, int alpha) {
    for (int k = spread; k >= 1; k--) {
        int a = alpha * (spread - k + 1) / (spread * 3 / 2 + 1);
        gfx_rrect_border(x - k, y - k + spread / 2, w + 2 * k, h + 2 * k, r + k, ARGB(a, 0, 0, 0));
    }
}
void gfx_line(int x0, int y0, int x1, int y1, int t, u32 c) {
    int dx = x1 > x0 ? x1 - x0 : x0 - x1, dy = -(y1 > y0 ? y1 - y0 : y0 - y1);
    int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx + dy;
    for (;;) {
        gfx_fill(x0 - t / 2, y0 - t / 2, t, t, c);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}
void gfx_blit(const u32 *src) { memcpy(gfx_bb, src, (size_t)gfx_w * gfx_h * 4); }

/* ---- text ---- */
static void glyph(int x, int y, u8 ch, u32 c, int s) {
    const u8 *g = font8x16[ch];
    for (int r = 0; r < 16; r++) {
        u8 bits = g[r]; if (!bits) continue;
        for (int cx = 0; cx < 8; cx++) {
            if (!(bits & (0x80 >> cx))) continue;
            if (s == 1) gfx_px(x + cx, y + r, c);
            else gfx_fill(x + cx * s, y + r * s, s, s, c);
        }
    }
}
int gfx_text_scaled(int x, int y, const char *t, u32 c, int s) {
    for (; *t; t++, x += 8 * s) if (*t != ' ') glyph(x, y, (u8)*t, c, s);
    return x;
}
int gfx_text(int x, int y, const char *t, u32 c) { return gfx_text_scaled(x, y, t, c, 1); }
int gfx_text_bold(int x, int y, const char *t, u32 c) { gfx_text_scaled(x + 1, y, t, c, 1); return gfx_text_scaled(x, y, t, c, 1); }
int gfx_text_w(const char *t) { return (int)strlen(t) * 8; }
void gfx_text_center(int x, int y, int w, const char *t, u32 c) { gfx_text(x + (w - gfx_text_w(t)) / 2, y, t, c); }
void gfx_text_right(int xr, int y, const char *t, u32 c) { gfx_text(xr - gfx_text_w(t), y, t, c); }
void gfx_text_clipped(int x, int y, int maxw, const char *t, u32 c) {
    int n = (int)strlen(t), fit = maxw / 8;
    if (n <= fit) { gfx_text(x, y, t, c); return; }
    if (fit < 3) return;
    char buf[96]; int k = fit - 2 < 90 ? fit - 2 : 90;
    memcpy(buf, t, k); buf[k] = '.'; buf[k + 1] = '.'; buf[k + 2] = 0;
    gfx_text(x, y, buf, c);
}

/* ---- presenting + software cursor ---- */
static const char *cur_art[19] = {
    "X           ", "XX          ", "X.X         ", "X..X        ", "X...X       ", "X....X      ", "X.....X     ",
    "X......X    ", "X.......X   ", "X........X  ", "X.....XXXXX ", "X..X..X     ", "X.X X..X    ", "XX  X..X    ",
    "X    X..X   ", "     X..X   ", "      X..X  ", "      X..X  ", "       XX   " };
#define CUR_W 12
#define CUR_H 19
static int cur_x = 512, cur_y = 384; static bool cur_on;

static inline u32 to_fb(u32 c) { return swap_rb ? ((c & 0xFF00FF00) | ((c & 0xFF) << 16) | ((c >> 16) & 0xFF)) : c; }
static void present_rect(int x, int y, int w, int h) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > gfx_w) w = gfx_w - x;
    if (y + h > gfx_h) h = gfx_h - y;
    if (w <= 0 || h <= 0) return;
    for (int j = y; j < y + h; j++) {
        u32 *d = (u32 *)(fb + (size_t)j * fb_pitch) + x; const u32 *s = gfx_bb + j * gfx_w + x;
        if (!swap_rb) memcpy(d, s, (size_t)w * 4); else for (int i = 0; i < w; i++) d[i] = to_fb(s[i]);
    }
}
static void draw_cursor(void) {
    if (!cur_on) return;
    for (int j = 0; j < CUR_H; j++)
        for (int i = 0; i < CUR_W; i++) {
            char ch = cur_art[j][i]; if (ch == ' ') continue;
            int x = cur_x + i, y = cur_y + j;
            if (x < 0 || y < 0 || x >= gfx_w || y >= gfx_h) continue;
            u32 col = ch == 'X' ? 0x101010 : 0xFFFFFF;
            *((u32 *)(fb + (size_t)y * fb_pitch) + x) = to_fb(col);
        }
}
void gfx_flip(void) { present_rect(0, 0, gfx_w, gfx_h); draw_cursor(); }
void gfx_cursor_show(bool on) {
    if (cur_on == on) return;
    if (!on) present_rect(cur_x, cur_y, CUR_W, CUR_H);
    cur_on = on; draw_cursor();
}
void gfx_cursor_move(int x, int y) {
    if (x == cur_x && y == cur_y) return;
    if (cur_on) present_rect(cur_x, cur_y, CUR_W, CUR_H);
    cur_x = x; cur_y = y; draw_cursor();
}

void gfx_panic_screen(const char *text) {
    gfx_reset_clip();
    gfx_fill(0, 0, gfx_w, gfx_h, RGB(0, 70, 140));
    gfx_text_scaled(60, 60, ":(", RGB(255, 255, 255), 6);
    gfx_text_scaled(60, 190, "WinLite 11 ran into a problem", RGB(255, 255, 255), 2);
    int y = 250;
    char line[100]; int n = 0;
    for (const char *p = text;; p++) {
        if (*p == '\n' || !*p || n > 90) { line[n] = 0; gfx_text(60, y, line, RGB(255, 255, 255)); y += 20; n = 0; if (!*p) break; if (*p == '\n') continue; }
        line[n++] = *p;
    }
    cur_on = false; gfx_flip();
}
