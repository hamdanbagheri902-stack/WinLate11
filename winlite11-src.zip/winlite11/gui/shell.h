#pragma once
#include "wm.h"
enum { POWER_NONE, POWER_SHUTDOWN, POWER_RESTART, POWER_OFF };
void shell_init(void);
void shell_render(void);                            /* draws the whole frame into the back buffer */
void shell_mouse(MouseKind k, int x, int y);
void shell_key(const KeyEvent *e);
void shell_tick(void);                              /* call every loop iteration */
void shell_set_theme(int dark, int accent, int wall);   /* -1 = keep current */
void shell_power(int action);
int  shell_power_state(void);
void shell_toggle_start(void);
bool shell_start_visible(void);
