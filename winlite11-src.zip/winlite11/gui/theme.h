#pragma once
#include "gfx.h"
typedef struct {
    bool dark; int accent_idx, wall_idx;
    u32 win, card, card_alt, text, dim, border, accent, accent_text, taskbar, menu, hover, press, close_red;
} Theme;
extern Theme T;
#define ACCENT_COUNT 6
#define WALL_COUNT 6
extern const u32 ACCENTS[ACCENT_COUNT];
extern const char *WALL_NAMES[WALL_COUNT];
void theme_init(void);
void theme_apply(bool dark, int accent_idx);
void wall_render(int preset, bool dark);     /* (re)builds the cached wallpaper */
void wall_begin(int preset, bool dark);      /* incremental build: call wall_step until it returns true */
bool wall_step(int rows);
void wall_preset_info(int idx, u32 *top, u32 *bot, u32 *blob);
const u32 *wall_buffer(void);
