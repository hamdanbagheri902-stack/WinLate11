/* Boot splash: logo, spinner, wallpaper built incrementally so the spinner keeps moving, then a fade into the desktop. */
#include "shell.h"
#include "../kernel/cpu.h"
#include "../kernel/desktop.h"
#include "../drivers/drivers.h"

static void wait_ticks(u32 n) { u32 t = pit_ticks(); while (pit_ticks() - t < n) idle_wait(); }

static void splash_frame(void) {
    for (int y = 0; y < gfx_h; y++) gfx_hline(0, y, gfx_w, gfx_lerp(0xFF0B1020, 0xFF161E36, y * 256 / gfx_h));
    ui_logo(gfx_w / 2 - 60, gfx_h / 2 - 130, 120);
    ui_spinner(gfx_w / 2, gfx_h / 2 + 70, pit_ticks(), 0xFFFFFFFF);
    gfx_text_center(0, gfx_h - 40, gfx_w, "WinLite 11", RGB(120, 130, 160));
    gfx_flip();
}
void splash_boot(void) {
    u32 t0 = pit_ticks();
    wall_begin(T.wall_idx, T.dark);
    bool done = false;
    while (!done || pit_ticks() - t0 < 220) {
        if (!done) done = wall_step(16);
        splash_frame();
        wait_ticks(1);
    }
    for (int a = 255; a > 0; a -= 36) {
        shell_render();
        gfx_fill(0, 0, gfx_w, gfx_h, ARGB(a, 11, 16, 32));
        gfx_flip();
        wait_ticks(2);
    }
}
