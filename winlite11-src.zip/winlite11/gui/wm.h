#pragma once
#include "ui.h"

#define TITLE_H 32
#define TASKBAR_H 48
typedef enum { EV_DOWN, EV_UP, EV_DRAG } MouseKind;
typedef struct Window Window;
struct Window {
    char title[48];
    int x, y, w, h;                 /* outer frame, including the title bar */
    int rx, ry, rw, rh;             /* restore rect (when maximized) */
    int min_w, min_h;
    bool alive, minimized, maximized;
    int app;
    void *data;
    void (*draw)(Window *, int cx, int cy, int cw, int ch);              /* client area, absolute coords */
    void (*key)(Window *, const KeyEvent *);
    void (*mouse)(Window *, MouseKind, int mx, int my);                  /* client-relative coords */
    void (*closed)(Window *);
};

Window *wm_create(const char *title, int app, int w, int h);
void    wm_close(Window *w);
void    wm_focus(Window *w);
void    wm_minimize(Window *w);
void    wm_toggle_max(Window *w);
void    wm_set_title(Window *w, const char *t);
Window *wm_top(void);                         /* focused (top-most visible) window */
Window *wm_find_app(int app);                 /* top-most window of an app, or NULL */
int     wm_count_app(int app);
int     wm_count(void);
void    wm_cycle(void);                       /* Alt+Tab */
void    wm_minimize_all(void);
void    wm_draw_all(void);
bool    wm_mouse(MouseKind k, int x, int y);  /* true if a window consumed the event */
bool    wm_key(const KeyEvent *e);
bool    wm_hover(const Window *w, int ax, int ay, int aw, int ah);  /* pointer inside rect and w is on top there */
bool    wm_busy(void);                        /* a drag/resize/press is in progress */
extern bool (*wm_overlay_open)(void);         /* set by shell: menus block hover */
