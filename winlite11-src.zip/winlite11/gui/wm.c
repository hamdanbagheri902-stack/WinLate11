/* Window manager: z-ordered, draggable, resizable (bottom-right grip), minimize/maximize/close. */
#include "wm.h"
#include "../kernel/klib.h"
#include "../drivers/drivers.h"

#define MAX_WIN 24
#define BTN_W 46
#define GRIP 14
static Window wins[MAX_WIN];
static Window *z[MAX_WIN];            /* back-to-front */
static int nz;
bool (*wm_overlay_open)(void);

enum { CAP_NONE, CAP_DRAG, CAP_RESIZE, CAP_CLIENT, CAP_BTN };
static int cap_mode, cap_btn, cap_dx, cap_dy;
static Window *cap_win;
static u32 last_title_click; static Window *last_title_win;

static void screen_work(int *w, int *h) { *w = gfx_w; *h = gfx_h - TASKBAR_H; }
static void zremove(Window *w) {
    int j = 0;
    for (int i = 0; i < nz; i++) if (z[i] != w) z[j++] = z[i];
    nz = j;
}
int wm_count(void) { int n = 0; for (int i = 0; i < nz; i++) if (z[i]->alive) n++; return n; }

Window *wm_create(const char *title, int app, int w, int h) {
    Window *win = 0;
    for (int i = 0; i < MAX_WIN; i++) if (!wins[i].alive) { win = &wins[i]; break; }
    if (!win) return 0;
    static int cascade;
    int sw, sh; screen_work(&sw, &sh);
    if (w > sw - 20) w = sw - 20;
    if (h > sh - 20) h = sh - 20;
    memset(win, 0, sizeof *win);
    kstrlcpy(win->title, title, sizeof win->title);
    win->app = app; win->w = w; win->h = h; win->min_w = 260; win->min_h = 160; win->alive = true;
    int k = cascade++ % 8;
    win->x = imax(8, imin(sw - w - 8, (sw - w) / 2 - 90 + k * 30));
    win->y = imax(8, imin(sh - h - 8, (sh - h) / 2 - 40 + k * 26));
    z[nz++] = win;
    wm_focus(win);
    return win;
}
void wm_close(Window *w) {
    if (!w || !w->alive) return;
    if (w->closed) w->closed(w);
    w->alive = false; zremove(w);
    if (cap_win == w) { cap_win = 0; cap_mode = CAP_NONE; }
    ui_invalidate();
}
void wm_focus(Window *w) {
    if (!w || !w->alive) return;
    w->minimized = false; zremove(w); z[nz++] = w; ui_invalidate();
}
Window *wm_top(void) {
    for (int i = nz - 1; i >= 0; i--) if (z[i]->alive && !z[i]->minimized) return z[i];
    return 0;
}
void wm_minimize(Window *w) { if (w) { w->minimized = true; if (cap_win == w) { cap_win = 0; cap_mode = CAP_NONE; } ui_invalidate(); } }
void wm_minimize_all(void) { for (int i = 0; i < nz; i++) z[i]->minimized = true; ui_invalidate(); }
void wm_toggle_max(Window *w) {
    int sw, sh; screen_work(&sw, &sh);
    if (!w->maximized) {
        w->rx = w->x; w->ry = w->y; w->rw = w->w; w->rh = w->h;
        w->x = 0; w->y = 0; w->w = sw; w->h = sh; w->maximized = true;
    } else {
        w->x = w->rx; w->y = w->ry; w->w = w->rw; w->h = w->rh; w->maximized = false;
    }
    ui_invalidate();
}
void wm_set_title(Window *w, const char *t) { kstrlcpy(w->title, t, sizeof w->title); ui_invalidate(); }
Window *wm_find_app(int app) {
    for (int i = nz - 1; i >= 0; i--) if (z[i]->alive && z[i]->app == app) return z[i];
    return 0;
}
int wm_count_app(int app) { int n = 0; for (int i = 0; i < nz; i++) if (z[i]->alive && z[i]->app == app) n++; return n; }
void wm_cycle(void) {
    /* send the top-most visible window to the back and focus the next one */
    Window *top = wm_top();
    if (!top || nz < 2) return;
    zremove(top);
    for (int i = nz; i > 0; i--) z[i] = z[i - 1];
    z[0] = top; nz++;
    Window *n = wm_top();
    if (n) wm_focus(n);
    ui_invalidate();
}

static Window *window_at(int x, int y) {
    for (int i = nz - 1; i >= 0; i--) {
        Window *w = z[i];
        if (w->alive && !w->minimized && pt_in(w->x, w->y, w->w, w->h, x, y)) return w;
    }
    return 0;
}
bool wm_hover(const Window *w, int ax, int ay, int aw, int ah) {
    if (wm_overlay_open && wm_overlay_open()) return false;
    if (!pt_in(ax, ay, aw, ah, g_mx, g_my)) return false;
    if (cap_mode != CAP_NONE && cap_win != w) return false;
    return window_at(g_mx, g_my) == w;
}
bool wm_busy(void) { return cap_mode != CAP_NONE; }

/* ---------- drawing ---------- */
static void draw_controls(Window *w, bool focused) {
    int bx = w->x + w->w - BTN_W * 3, by = w->y;
    u32 fg = focused ? T.text : T.dim;
    int hov = -1;
    if (!(wm_overlay_open && wm_overlay_open()) && window_at(g_mx, g_my) == w)
        for (int i = 0; i < 3; i++) if (pt_in(bx + i * BTN_W, by, BTN_W, TITLE_H, g_mx, g_my)) hov = i;
    Rect old = gfx_set_clip((Rect){ w->x, w->y, w->w, TITLE_H });
    for (int i = 0; i < 3; i++) {
        int x = bx + i * BTN_W; bool pressed = cap_mode == CAP_BTN && cap_win == w && cap_btn == i;
        u32 col = fg;
        if (i == 2 && (hov == 2 || pressed)) {
            gfx_rrect(x, by, BTN_W + (w->maximized ? 0 : 0), TITLE_H + 8, w->maximized ? 0 : 8, pressed ? gfx_lerp(T.close_red, 0xFF000000, 40) : T.close_red);
            col = 0xFFFFFFFF;
        } else if (hov == i || pressed) gfx_fill(x, by, BTN_W, TITLE_H, pressed ? T.press : T.hover);
        int cx = x + BTN_W / 2, cy = by + TITLE_H / 2;
        if (i == 0) gfx_fill(cx - 5, cy, 11, 1, col);
        else if (i == 1) {
            if (!w->maximized) gfx_rrect_border(cx - 5, cy - 5, 11, 11, 2, col);
            else { gfx_rrect_border(cx - 3, cy - 5, 9, 9, 2, col); gfx_rrect_border(cx - 5, cy - 3, 9, 9, 2, col); }
        } else { gfx_line(cx - 5, cy - 5, cx + 5, cy + 5, 1, col); gfx_line(cx + 5, cy - 5, cx - 5, cy + 5, 1, col); }
    }
    gfx_set_clip(old);
}
static void draw_window(Window *w, bool focused) {
    int r = w->maximized ? 0 : 8;
    if (!w->maximized) gfx_shadow(w->x, w->y, w->w, w->h, r, focused ? 14 : 8, focused ? 70 : 34);
    gfx_rrect(w->x, w->y, w->w, w->h, r, T.win);
    gfx_rrect_border(w->x, w->y, w->w, w->h, r, focused ? gfx_lerp(T.border, T.accent, 90) : T.border);
    ui_app_icon(w->app, w->x + 10, w->y + 8, 16);
    gfx_text_clipped(w->x + 34, w->y + 8, w->w - 34 - BTN_W * 3 - 8, w->title, focused ? T.text : T.dim);
    draw_controls(w, focused);
    if (w->draw) {
        Rect old = gfx_set_clip((Rect){ w->x + 1, w->y + TITLE_H, w->w - 2, w->h - TITLE_H - 1 });
        w->draw(w, w->x + 1, w->y + TITLE_H, w->w - 2, w->h - TITLE_H - 1);
        gfx_set_clip(old);
    }
    if (!w->maximized)   /* resize grip dots */
        for (int i = 0; i < 3; i++) for (int j = 0; j <= i; j++)
            gfx_px(w->x + w->w - 5 - (2 - i) * 3 - 1, w->y + w->h - 5 - j * 3 - (2 - i) * 0, T.dim);
}
void wm_draw_all(void) {
    Window *top = wm_top();
    for (int i = 0; i < nz; i++) if (z[i]->alive && !z[i]->minimized) draw_window(z[i], z[i] == top);
}

/* ---------- input ---------- */
bool wm_key(const KeyEvent *e) {
    Window *w = wm_top();
    if (!w) return false;
    if (w->key) w->key(w, e);
    ui_invalidate();
    return true;
}
bool wm_mouse(MouseKind k, int x, int y) {
    int sw, sh; screen_work(&sw, &sh);
    if (k == EV_DOWN) {
        Window *w = window_at(x, y);
        if (!w) return false;
        wm_focus(w);
        cap_win = w;
        if (!w->maximized && x >= w->x + w->w - GRIP && y >= w->y + w->h - GRIP) {
            cap_mode = CAP_RESIZE; cap_dx = w->x + w->w - x; cap_dy = w->y + w->h - y;
        } else if (y < w->y + TITLE_H) {
            int bx = w->x + w->w - BTN_W * 3;
            if (x >= bx) { cap_mode = CAP_BTN; cap_btn = (x - bx) / BTN_W; }
            else {
                u32 now = pit_ticks();
                if (last_title_win == w && now - last_title_click < 40) { wm_toggle_max(w); last_title_win = 0; cap_mode = CAP_NONE; cap_win = 0; return true; }
                last_title_win = w; last_title_click = now;
                cap_mode = CAP_DRAG; cap_dx = x - w->x; cap_dy = y - w->y;
            }
        } else {
            cap_mode = CAP_CLIENT;
            if (w->mouse) w->mouse(w, EV_DOWN, x - (w->x + 1), y - (w->y + TITLE_H));
        }
        ui_invalidate();
        return true;
    }
    if (cap_mode == CAP_NONE || !cap_win) return false;
    Window *w = cap_win;
    if (k == EV_DRAG) {
        if (cap_mode == CAP_DRAG) {
            if (w->maximized) {            /* dragging a maximized window restores it under the pointer */
                int rw = w->rw; wm_toggle_max(w);
                w->x = x - rw / 2; w->y = y - 16; cap_dx = x - w->x; cap_dy = y - w->y;
            }
            w->x = x - cap_dx; w->y = y - cap_dy;
            w->y = imax(0, imin(w->y, sh - TITLE_H));
            w->x = imax(-w->w + 120, imin(w->x, sw - 120));
        } else if (cap_mode == CAP_RESIZE) {
            w->w = imax(w->min_w, imin(sw - w->x, x + cap_dx - w->x));
            w->h = imax(w->min_h, imin(sh - w->y, y + cap_dy - w->y));
        } else if (cap_mode == CAP_CLIENT && w->mouse) w->mouse(w, EV_DRAG, x - (w->x + 1), y - (w->y + TITLE_H));
        ui_invalidate();
        return true;
    }
    if (k == EV_UP) {
        int mode = cap_mode; cap_mode = CAP_NONE; cap_win = 0;
        if (mode == CAP_BTN) {
            int bx = w->x + w->w - BTN_W * 3;
            if (pt_in(bx + cap_btn * BTN_W, w->y, BTN_W, TITLE_H, x, y)) {
                if (cap_btn == 0) wm_minimize(w);
                else if (cap_btn == 1) wm_toggle_max(w);
                else wm_close(w);
            }
        } else if (mode == CAP_CLIENT && w->mouse) w->mouse(w, EV_UP, x - (w->x + 1), y - (w->y + TITLE_H));
        ui_invalidate();
        return true;
    }
    return true;
}
