#pragma once
#include "../kernel/types.h"
/* Colors are 0xAARRGGBB (A=255 opaque). The back buffer stores 0x00RRGGBB. */
typedef struct { int x, y, w, h; } Rect;
#define ARGB(a, r, g, b) (((u32)(a) << 24) | ((u32)(r) << 16) | ((u32)(g) << 8) | (u32)(b))
#define RGB(r, g, b) ARGB(255, r, g, b)
#define COL_ALPHA(c, a) (((c) & 0x00FFFFFF) | ((u32)(a) << 24))

extern int gfx_w, gfx_h;
extern bool gfx_ready;
extern u32 *gfx_bb;

void gfx_init(void *fb, int w, int h, int pitch_bytes, bool swap_rb);
Rect gfx_set_clip(Rect r);                 /* intersects with screen, returns previous clip */
void gfx_reset_clip(void);
Rect gfx_get_clip(void);

u32  gfx_blend(u32 dst, u32 src);
u32  gfx_lerp(u32 a, u32 b, int t256);     /* per-channel incl. alpha, t in 0..256 */
void gfx_px(int x, int y, u32 c);
void gfx_fill(int x, int y, int w, int h, u32 c);
void gfx_hline(int x, int y, int w, u32 c);
void gfx_vline(int x, int y, int h, u32 c);
void gfx_rrect(int x, int y, int w, int h, int r, u32 c);
void gfx_rrect_grad(int x, int y, int w, int h, int r, u32 top, u32 bottom);
void gfx_rrect_border(int x, int y, int w, int h, int r, u32 c);
void gfx_circle(int cx, int cy, int rad, u32 c);
void gfx_shadow(int x, int y, int w, int h, int r, int spread, int alpha);
void gfx_line(int x0, int y0, int x1, int y1, int thick, u32 c);
void gfx_blit(const u32 *src);             /* full-screen copy into back buffer */

int  gfx_text(int x, int y, const char *s, u32 c);              /* returns x after text */
int  gfx_text_bold(int x, int y, const char *s, u32 c);
int  gfx_text_scaled(int x, int y, const char *s, u32 c, int scale);
int  gfx_text_w(const char *s);
void gfx_text_center(int x, int y, int w, const char *s, u32 c);   /* centered horizontally in [x,x+w) */
void gfx_text_right(int xr, int y, const char *s, u32 c);
void gfx_text_clipped(int x, int y, int maxw, const char *s, u32 c);  /* truncates with ".." */

void gfx_flip(void);                       /* back buffer -> screen, then cursor */
void gfx_cursor_show(bool on);
void gfx_cursor_move(int x, int y);        /* cheap: touches only cursor rectangles on screen */
void gfx_panic_screen(const char *text);
