#pragma once
#include "gfx.h"
#include "theme.h"
#include "../drivers/input.h"

extern int g_mx, g_my;        /* current pointer position */
extern bool g_dirty;          /* set when the screen needs a full redraw */
static inline void ui_invalidate(void) { g_dirty = true; }
static inline bool pt_in(int x, int y, int w, int h, int px, int py) { return px >= x && py >= y && px < x + w && py < y + h; }
static inline int imin(int a, int b) { return a < b ? a : b; }
static inline int imax(int a, int b) { return a > b ? a : b; }

enum { APP_EXPLORER, APP_NOTEPAD, APP_CALC, APP_TERMINAL, APP_SETTINGS, APP_COUNT };
extern const char *APP_NAMES[APP_COUNT];

void ui_app_icon(int app, int x, int y, int s);
void ui_folder_icon(int x, int y, int s);
void ui_file_icon(int x, int y, int s);
void ui_logo(int x, int y, int s);                 /* the WinLite blossom mark */
void ui_button(int x, int y, int w, int h, const char *label, bool hot, bool down, bool primary);
void ui_switch(int x, int y, bool on, bool hot);   /* 40x20 toggle */
void ui_spinner(int cx, int cy, u32 tick, u32 color);
