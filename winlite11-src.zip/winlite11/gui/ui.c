/* Shared UI pieces: original vector icons drawn with the gfx primitives, buttons, switch, spinner. */
#include "ui.h"

int g_mx = 512, g_my = 384;
bool g_dirty = true;
const char *APP_NAMES[APP_COUNT] = { "File Explorer", "Notepad", "Calculator", "Terminal", "Settings" };

#define S(v) (((v) * s + 16) / 32)
static inline int S1(int v, int s) { int r = ((v) * s + 16) / 32; return r < 1 ? 1 : r; }

void ui_folder_icon(int x, int y, int s) {
    gfx_rrect(x + S(2), y + S(6), S(13), S(8), S(3), RGB(0xD9, 0x9A, 0x16));
    gfx_rrect_grad(x + S(2), y + S(9), S(28), S(19), S(3), RGB(0xFF, 0xD6, 0x63), RGB(0xF2, 0xA9, 0x1E));
    gfx_fill(x + S(4), y + S(10), S(24), S1(1, s), ARGB(130, 255, 255, 255));
}
void ui_file_icon(int x, int y, int s) {
    gfx_rrect(x + S(7), y + S(3), S(18), S(26), S(2), RGB(0xFA, 0xFA, 0xFA));
    gfx_rrect_border(x + S(7), y + S(3), S(18), S(26), S(2), RGB(0xB4, 0xB9, 0xC2));
    for (int i = 0; i < 4; i++) gfx_fill(x + S(10), y + S(10 + i * 4), S(12), S1(1, s), RGB(0xA8, 0xB4, 0xC6));
}
static void icon_notepad(int x, int y, int s) {
    gfx_rrect(x + S(5), y + S(3), S(22), S(26), S(3), RGB(0xFB, 0xFB, 0xFB));
    gfx_rrect(x + S(5), y + S(3), S(22), S(9), S(3), RGB(0x2F, 0x80, 0xED));
    gfx_fill(x + S(5), y + S(8), S(22), S(4), RGB(0x2F, 0x80, 0xED));
    gfx_rrect_border(x + S(5), y + S(3), S(22), S(26), S(3), RGB(0x9A, 0xA6, 0xB8));
    for (int i = 0; i < 3; i++) gfx_fill(x + S(9), y + S(15 + i * 4), S(i == 1 ? 11 : 14), S1(1, s), RGB(0x8E, 0x9B, 0xB0));
}
static void icon_calc(int x, int y, int s) {
    gfx_rrect(x + S(4), y + S(3), S(24), S(26), S(4), RGB(0x3A, 0x3F, 0x4B));
    gfx_rrect(x + S(7), y + S(6), S(18), S(7), S(2), RGB(0x9A, 0xE6, 0xB4));
    for (int r = 0; r < 3; r++)
        for (int c = 0; c < 3; c++)
            gfx_rrect(x + S(7 + c * 6), y + S(15 + r * 5), S(5), S(4), S1(1, s),
                      (c == 2 && r == 2) ? RGB(0xFF, 0x9F, 0x43) : RGB(0xD5, 0xDB, 0xE5));
}
static void icon_term(int x, int y, int s) {
    gfx_rrect(x + S(3), y + S(5), S(26), S(22), S(4), RGB(0x1E, 0x22, 0x2E));
    gfx_rrect(x + S(3), y + S(5), S(26), S(5), S(4), RGB(0x3C, 0x43, 0x55));
    gfx_fill(x + S(3), y + S(8), S(26), S(2), RGB(0x3C, 0x43, 0x55));
    int t = S1(2, s);
    gfx_line(x + S(8), y + S(14), x + S(12), y + S(17), t, RGB(0x6E, 0xE7, 0x9B));
    gfx_line(x + S(12), y + S(17), x + S(8), y + S(20), t, RGB(0x6E, 0xE7, 0x9B));
    gfx_fill(x + S(15), y + S(21), S(7), t, RGB(0xE6, 0xEA, 0xF2));
}
static void icon_gear(int x, int y, int s) {
    static const int ox[8] = { 0, 8, 11, 8, 0, -8, -11, -8 }, oy[8] = { -11, -8, 0, 8, 11, 8, 0, -8 };
    int cx = x + s / 2, cy = y + s / 2; u32 g = RGB(0x6B, 0x76, 0x8A);
    for (int i = 0; i < 8; i++) gfx_circle(cx + ox[i] * s / 32, cy + oy[i] * s / 32, S1(3, s), g);
    gfx_circle(cx, cy, S1(9, s), g);
    gfx_circle(cx, cy, S1(4, s), RGB(0xEA, 0xEE, 0xF4));
}
void ui_app_icon(int app, int x, int y, int s) {
    switch (app) {
    case APP_EXPLORER: ui_folder_icon(x, y, s); break;
    case APP_NOTEPAD:  icon_notepad(x, y, s); break;
    case APP_CALC:     icon_calc(x, y, s); break;
    case APP_TERMINAL: icon_term(x, y, s); break;
    case APP_SETTINGS: icon_gear(x, y, s); break;
    }
}
/* Four petals around a center: original mark, not a window pane. */
void ui_logo(int x, int y, int s) {
    int cx = x + s / 2, cy = y + s / 2, r = s * 9 / 32, d = s * 8 / 32;
    gfx_circle(cx, cy - d, r, T.accent);
    gfx_circle(cx + d, cy, r, gfx_lerp(T.accent, 0xFF7FD1F5, 110));
    gfx_circle(cx, cy + d, r, gfx_lerp(T.accent, 0xFFA48CF2, 150));
    gfx_circle(cx - d, cy, r, gfx_lerp(T.accent, 0xFF5CE0C6, 120));
    gfx_circle(cx, cy, r * 2 / 3, ARGB(210, 255, 255, 255));
}
void ui_button(int x, int y, int w, int h, const char *label, bool hot, bool down, bool primary) {
    gfx_rrect(x, y, w, h, 5, primary ? T.accent : T.card);
    if (!primary) gfx_rrect_border(x, y, w, h, 5, T.border);
    if (hot) gfx_rrect(x, y, w, h, 5, primary ? ARGB(40, 255, 255, 255) : T.hover);
    if (down) gfx_rrect(x, y, w, h, 5, T.press);
    gfx_text_center(x, y + (h - 16) / 2, w, label, primary ? T.accent_text : T.text);
}
void ui_switch(int x, int y, bool on, bool hot) {
    if (on) gfx_rrect(x, y, 40, 20, 10, T.accent);
    else { gfx_rrect(x, y, 40, 20, 10, hot ? T.hover : ARGB(0, 0, 0, 0)); gfx_rrect_border(x, y, 40, 20, 10, T.dim); }
    gfx_circle(x + (on ? 29 : 11), y + 10, on ? 5 : 4, on ? T.accent_text : T.dim);
}
void ui_spinner(int cx, int cy, u32 tick, u32 color) {
    static const int px[8] = { 0, 13, 18, 13, 0, -13, -18, -13 }, py[8] = { -18, -13, 0, 13, 18, 13, 0, -13 };
    int head = (int)((tick / 5) & 7);
    for (int i = 0; i < 8; i++) {
        int dist = (head - i) & 7;
        int a = 255 - dist * 30; if (a < 30) a = 30;
        gfx_circle(cx + px[i], cy + py[i], dist == 0 ? 5 : 4, COL_ALPHA(color, a));
    }
}
