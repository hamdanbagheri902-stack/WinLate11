/* Terminal: a tiny shell over the RAM filesystem. */
#include "apps.h"
#include "../kernel/klib.h"
#include "../kernel/boot_info.h"
#include "../drivers/drivers.h"

#define TL_MAX 300
#define TL_W 100
#define WRAP 78
#define HIST 16
typedef struct {
    char lines[TL_MAX][TL_W]; int nl, col;
    char in[160]; int ilen;
    FsNode *cwd; int scroll;
    char hist[HIST][160]; int nh, hpos;
} Term;

static void newline(Term *t) {
    if (t->nl >= TL_MAX - 1) { memmove(t->lines[0], t->lines[1], (TL_MAX - 1) * TL_W); t->nl = TL_MAX - 2; }
    t->nl++; t->lines[t->nl][0] = 0; t->col = 0;
}
static void puts_(Term *t, const char *s) {
    for (; *s; s++) {
        if (*s == '\n') { newline(t); continue; }
        if (*s == '\r') continue;
        if (t->col >= WRAP) newline(t);
        char ch = (*s == '\t') ? ' ' : *s;
        if ((u8)ch < 32 || (u8)ch > 126) ch = '?';
        t->lines[t->nl][t->col++] = ch; t->lines[t->nl][t->col] = 0;
    }
}
static void say(Term *t, const char *s) { puts_(t, s); puts_(t, "\n"); }
static void sayf(Term *t, const char *fmtstr, ...) {
    char b[256]; va_list ap; va_start(ap, fmtstr); kvsnprintf(b, sizeof b, fmtstr, ap); va_end(ap); say(t, b);
}
static void prompt_str(Term *t, char *out, size_t n) {
    char p[96]; fs_path(t->cwd, p, sizeof p); ksnprintf(out, n, "WL %s> ", p);
}
static FsNode *resolve(Term *t, const char *p) { return fs_lookup(t->cwd, p); }

static const char *HELP =
    "Commands:\n"
    "  help                 show this list\n"
    "  ls [path]            list a folder          cd <path>   change folder\n"
    "  pwd                  print current folder   cat <file>  show a file\n"
    "  echo <text> [> f]    print text, or write it to a file (>> appends)\n"
    "  mkdir <name>         create a folder        touch <f>   create a file\n"
    "  rm <path>            delete a file/folder   clear       clear the screen\n"
    "  date                 current RTC time       mem         memory usage\n"
    "  uptime               time since boot        about       about WinLite 11\n"
    "  theme dark|light     switch theme           theme accent|wall <n>\n"
    "  start <app>          explorer notepad calc terminal settings\n"
    "  reboot / shutdown    restart or power off";

static int split(char *line, char **argv, int max) {
    int n = 0; char *p = line;
    while (*p && n < max) {
        while (*p == ' ') p++;
        if (!*p) break;
        argv[n++] = p;
        while (*p && *p != ' ') p++;
        if (*p) *p++ = 0;
    }
    return n;
}
static void cmd_echo(Term *t, const char *rest) {
    char text[160]; kstrlcpy(text, rest, sizeof text);
    char *gt = 0; for (char *p = text; *p; p++) if (*p == '>') { gt = p; break; }
    if (!gt) { say(t, text); return; }
    bool app = gt[1] == '>'; char *file = gt + (app ? 2 : 1);
    *gt = 0;
    int l = (int)strlen(text); while (l > 0 && text[l - 1] == ' ') text[--l] = 0;
    while (*file == ' ') file++;
    if (!*file) { say(t, "echo: missing file name"); return; }
    FsNode *f = resolve(t, file);
    if (!f) { char leaf[32]; FsNode *d = fs_lookup_parent(t->cwd, file, leaf); f = d ? fs_create(d, leaf, false) : 0; }
    if (!f || f->is_dir) { say(t, "echo: cannot write there"); return; }
    char line[170]; ksnprintf(line, sizeof line, "%s\n", text);
    if (app) fs_append(f, line, (u32)strlen(line)); else fs_write(f, line, (u32)strlen(line));
}
static void run(Term *t, char *line) {
    char raw[160]; kstrlcpy(raw, line, sizeof raw);
    char *argv[8]; int argc = split(line, argv, 8);
    if (!argc) return;
    const char *c = argv[0];
    if (!strcmp(c, "help")) say(t, HELP);
    else if (!strcmp(c, "ls") || !strcmp(c, "dir")) {
        FsNode *d = argc > 1 ? resolve(t, argv[1]) : t->cwd;
        if (!d) { say(t, "ls: no such folder"); return; }
        if (!d->is_dir) { sayf(t, "%s", d->name); return; }
        if (!d->child) say(t, "(empty)");
        for (FsNode *n = d->child; n; n = n->next) {
            if (n->is_dir) sayf(t, "  <DIR>     %s", n->name); else sayf(t, "  %-9u %s", n->size, n->name);
        }
    }
    else if (!strcmp(c, "cd")) {
        if (argc < 2) { t->cwd = fs_root(); return; }
        FsNode *d = resolve(t, argv[1]);
        if (!d || !d->is_dir) say(t, "cd: no such folder"); else t->cwd = d;
    }
    else if (!strcmp(c, "pwd")) { char p[96]; fs_path(t->cwd, p, sizeof p); say(t, p); }
    else if (!strcmp(c, "cat") || !strcmp(c, "type")) {
        if (argc < 2) { say(t, "usage: cat <file>"); return; }
        FsNode *f = resolve(t, argv[1]);
        if (!f) say(t, "cat: no such file"); else if (f->is_dir) say(t, "cat: is a folder");
        else { char tmp[2] = { 0, 0 }; for (u32 i = 0; i < f->size; i++) { tmp[0] = (char)f->data[i]; puts_(t, tmp); } if (f->size && f->data[f->size - 1] != '\n') puts_(t, "\n"); }
    }
    else if (!strcmp(c, "echo")) {
        const char *p = raw + 4; while (*p == ' ') p++;
        cmd_echo(t, p);
    }
    else if (!strcmp(c, "clear") || !strcmp(c, "cls")) { t->nl = 0; t->lines[0][0] = 0; t->col = 0; t->scroll = 0; }
    else if (!strcmp(c, "mkdir")) {
        if (argc < 2) { say(t, "usage: mkdir <name>"); return; }
        char leaf[32]; FsNode *d = fs_lookup_parent(t->cwd, argv[1], leaf);
        if (!d || !fs_create(d, leaf, true)) say(t, "mkdir: cannot create (exists or bad name)");
    }
    else if (!strcmp(c, "touch")) {
        if (argc < 2) { say(t, "usage: touch <file>"); return; }
        char leaf[32]; FsNode *d = fs_lookup_parent(t->cwd, argv[1], leaf);
        if (resolve(t, argv[1])) return;
        if (!d || !fs_create(d, leaf, false)) say(t, "touch: cannot create file");
    }
    else if (!strcmp(c, "rm") || !strcmp(c, "del")) {
        if (argc < 2) { say(t, "usage: rm <path>"); return; }
        FsNode *f = resolve(t, argv[1]);
        if (!f || !f->parent) { say(t, "rm: nothing to delete"); return; }
        bool inside = false; for (FsNode *p = t->cwd; p; p = p->parent) if (p == f) inside = true;
        if (inside) say(t, "rm: that is the current folder or its parent");
        else fs_remove(f);
    }
    else if (!strcmp(c, "date")) { DateTime d; rtc_read(&d); sayf(t, "%04d-%02d-%02d %02d:%02d:%02d (RTC)", d.year, d.month, d.day, d.hour, d.min, d.sec); }
    else if (!strcmp(c, "uptime")) { u32 s = pit_ticks() / 100; sayf(t, "up %u min %u s", s / 60, s % 60); }
    else if (!strcmp(c, "mem")) {
        sayf(t, "RAM reported by GRUB : %u MB", g_boot.mem_kb / 1024);
        sayf(t, "Kernel heap         : %u KB used of %u MB", (u32)kheap_used() / 1024, (u32)kheap_total() / (1024 * 1024));
        sayf(t, "RAM disk            : %u bytes in files", fs_total_bytes());
    }
    else if (!strcmp(c, "about")) {
        say(t, "+--------------------------------------------------+");
        say(t, "|   WinLite 11  -  a hobby operating system        |");
        say(t, "+--------------------------------------------------+");
        say(t, "WinLite 11 - a hobby operating system (i386, Multiboot2).");
        say(t, "Original kernel, window manager, font and icons. No external libraries.");
    }
    else if (!strcmp(c, "theme")) {
        if (argc >= 2 && !strcmp(argv[1], "dark")) shell_set_theme(1, -1, -1);
        else if (argc >= 2 && !strcmp(argv[1], "light")) shell_set_theme(0, -1, -1);
        else if (argc >= 3 && !strcmp(argv[1], "accent")) shell_set_theme(-1, imax(0, imin(ACCENT_COUNT - 1, katoi(argv[2]))), -1);
        else if (argc >= 3 && !strcmp(argv[1], "wall")) shell_set_theme(-1, -1, imax(0, imin(WALL_COUNT - 1, katoi(argv[2]))));
        else say(t, "usage: theme dark|light | theme accent <0-5> | theme wall <0-5>");
    }
    else if (!strcmp(c, "start") || !strcmp(c, "open")) {
        if (argc < 2) { say(t, "usage: start <explorer|notepad|calc|terminal|settings>"); return; }
        int a = -1;
        if (!strcmp(argv[1], "explorer")) a = APP_EXPLORER; else if (!strcmp(argv[1], "notepad")) a = APP_NOTEPAD;
        else if (!strcmp(argv[1], "calc")) a = APP_CALC; else if (!strcmp(argv[1], "terminal")) a = APP_TERMINAL;
        else if (!strcmp(argv[1], "settings")) a = APP_SETTINGS;
        if (a < 0) { say(t, "start: unknown app"); return; }
        app_launch(a);
    }
    else if (!strcmp(c, "reboot") || !strcmp(c, "restart")) shell_power(POWER_RESTART);
    else if (!strcmp(c, "shutdown") || !strcmp(c, "poweroff")) shell_power(POWER_SHUTDOWN);
    else if (!strcmp(c, "whoami")) say(t, "winlite");
    else sayf(t, "'%s' is not recognized. Type 'help'.", c);
}
static void term_key(Window *w, const KeyEvent *e) {
    Term *t = w->data; int k = e->key;
    t->scroll = 0;
    if ((e->mods & MOD_CTRL) && k == 'l') { t->nl = 0; t->lines[0][0] = 0; t->col = 0; return; }
    if ((e->mods & MOD_CTRL) && k == 'c') { puts_(t, "^C\n"); t->ilen = 0; t->in[0] = 0; return; }
    if (k == KEY_ENTER) {
        char p[110]; prompt_str(t, p, sizeof p);
        puts_(t, p); puts_(t, t->in); puts_(t, "\n");
        char line[160]; kstrlcpy(line, t->in, sizeof line);
        if (t->ilen && (t->nh == 0 || strcmp(t->hist[(t->nh - 1) % HIST], t->in))) { kstrlcpy(t->hist[t->nh % HIST], t->in, 160); t->nh++; }
        t->hpos = t->nh; t->ilen = 0; t->in[0] = 0;
        if (!fs_valid(t->cwd)) t->cwd = fs_root();
        run(t, line);
    }
    else if (k == KEY_BACKSPACE) { if (t->ilen) t->in[--t->ilen] = 0; }
    else if (k == KEY_UP) { if (t->hpos > 0 && t->hpos > t->nh - HIST) { t->hpos--; kstrlcpy(t->in, t->hist[t->hpos % HIST], sizeof t->in); t->ilen = (int)strlen(t->in); } }
    else if (k == KEY_DOWN) { if (t->hpos < t->nh) { t->hpos++; if (t->hpos == t->nh) { t->in[0] = 0; t->ilen = 0; } else { kstrlcpy(t->in, t->hist[t->hpos % HIST], sizeof t->in); t->ilen = (int)strlen(t->in); } } }
    else if (k == KEY_PGUP) { t->scroll += 8; if (t->scroll > t->nl) t->scroll = t->nl; }
    else if (k == KEY_PGDN) { t->scroll -= 8; if (t->scroll < 0) t->scroll = 0; }
    else if (k >= 32 && k < 127 && !(e->mods & MOD_CTRL) && t->ilen < 150) { t->in[t->ilen++] = (char)k; t->in[t->ilen] = 0; }
}
static void term_draw(Window *w, int cx, int cy, int cw, int ch) {
    Term *t = w->data;
    if (!fs_valid(t->cwd)) t->cwd = fs_root();
    u32 bg = T.dark ? RGB(12, 12, 14) : RGB(24, 26, 32), fg = RGB(214, 218, 226), green = RGB(110, 231, 155);
    gfx_rrect(cx + 6, cy + 4, cw - 12, ch - 10, 8, bg);
    int cols = (cw - 12 - 16) / 8, rows = (ch - 10 - 12) / 16;
    if (rows < 2 || cols < 4) return;
    Rect old = gfx_set_clip((Rect){ cx + 10, cy + 8, cw - 20, ch - 18 });
    int R = rows - 1, first = imax(0, t->nl + 1 - R - t->scroll);
    int n = 0;
    for (int i = first; i <= t->nl && n < R; i++, n++) gfx_text_clipped(cx + 14, cy + 10 + n * 16, cols * 8, t->lines[i], fg);
    if (t->scroll == 0) {
        /* the last history line is the (empty) one being built: if it is non-empty, the prompt goes on the next row */
        int row = n; if (t->lines[t->nl][0] == 0 && n > 0) row = n - 1;
        char p[110]; prompt_str(t, p, sizeof p);
        int x = gfx_text(cx + 14, cy + 10 + row * 16, p, green);
        x = gfx_text(x, cy + 10 + row * 16, t->in, fg);
        if (((pit_ticks() / 50) & 1) == 0 && wm_top() == w) gfx_fill(x, cy + 10 + row * 16 + 13, 8, 2, fg);
    }
    gfx_set_clip(old);
}
static void term_closed(Window *w) { kfree(w->data); }

Window *terminal_open(void) {
    Term *t = kzalloc(sizeof *t); if (!t) return 0;
    t->cwd = fs_lookup(0, "/Documents"); if (!t->cwd) t->cwd = fs_root();
    Window *w = wm_create("Terminal", APP_TERMINAL, 680, 430);
    if (!w) { kfree(t); return 0; }
    w->data = t; w->draw = term_draw; w->key = term_key; w->closed = term_closed; w->min_w = 360; w->min_h = 200;
    say(t, "WinLite 11 Terminal  -  type 'help' for commands.");
    say(t, "");
    return w;
}
