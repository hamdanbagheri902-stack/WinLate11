/* Calculator: fixed-point (4 decimals, 9 integer digits) so it needs no floating point. */
#include "apps.h"
#include "../kernel/klib.h"

#define SC 10000LL
#define LIM 9999999999999LL
typedef struct { i64 acc, shown; int op; char entry[24]; bool typing, have_operand; const char *err; char expr[48]; int pressed; } Calc;

static const struct { const char *l; char a; } KEYS[24] = {
    {"%",'%'},{"CE",'e'},{"C",'c'},{"\x84",'b'},
    {"1/x",'i'},{"x^2",'q'},{"sqrt",'r'},{"\x80",'/'},
    {"7",'7'},{"8",'8'},{"9",'9'},{"\x81",'*'},
    {"4",'4'},{"5",'5'},{"6",'6'},{"\x82",'-'},
    {"1",'1'},{"2",'2'},{"3",'3'},{"+",'+'},
    {"\x83",'n'},{"0",'0'},{".",'.'},{"=",'='} };

static void fmt(i64 v, char *out, size_t n) {
    u64 a = v < 0 ? (u64)(-v) : (u64)v;
    char frac[8]; int fl = 4;
    ksnprintf(frac, sizeof frac, "%04u", (u32)(a % SC));
    while (fl > 0 && frac[fl - 1] == '0') fl--;
    frac[fl] = 0;
    ksnprintf(out, n, "%s%u%s%s", v < 0 ? "-" : "", (u32)(a / SC), fl ? "." : "", frac);
}
static i64 parse(const char *s) {
    bool neg = false; i64 ip = 0, fp = 0; int fd = 0; bool dot = false;
    if (*s == '-') { neg = true; s++; }
    for (; *s; s++) {
        if (*s == '.') dot = true;
        else if (!dot) ip = ip * 10 + (*s - '0');
        else if (fd < 4) { fp = fp * 10 + (*s - '0'); fd++; }
    }
    while (fd++ < 4) fp *= 10;
    i64 v = ip * SC + fp; return neg ? -v : v;
}
static i64 cur_val(Calc *c) { return c->typing ? parse(c->entry) : c->shown; }
static bool mul(i64 a, i64 b, i64 *out) {
    bool neg = (a < 0) ^ (b < 0);
    u64 ua = a < 0 ? (u64)(-a) : (u64)a, ub = b < 0 ? (u64)(-b) : (u64)b;
    u64 ah = ua / SC, al = ua % SC;
    if (ah && ub > (u64)LIM / ah) return false;
    u64 r = ah * ub + (al * ub + SC / 2) / SC;
    if (r > (u64)LIM) return false;
    *out = neg ? -(i64)r : (i64)r; return true;
}
static u64 isqrt64(u64 n) {
    u64 r = 0, bit = 1ULL << 62;
    while (bit > n) bit >>= 2;
    while (bit) { if (n >= r + bit) { n -= r + bit; r = (r >> 1) + bit; } else r >>= 1; bit >>= 2; }
    return r;
}
static void reset(Calc *c) { memset(c, 0, sizeof *c); c->pressed = -1; kstrlcpy(c->entry, "0", sizeof c->entry); c->typing = true; }
static bool apply(Calc *c, i64 a, int op, i64 b, i64 *out) {
    switch (op) {
    case '+': *out = a + b; break;
    case '-': *out = a - b; break;
    case '*': if (!mul(a, b, out)) { c->err = "Overflow"; return false; } return true;
    case '/': if (b == 0) { c->err = "Cannot divide by zero"; return false; }
              { bool neg = (a < 0) ^ (b < 0); u64 ua = a < 0 ? (u64)(-a) : (u64)a, ub = b < 0 ? (u64)(-b) : (u64)b;
                u64 q = (ua * SC + ub / 2) / ub; *out = neg ? -(i64)q : (i64)q; } break;
    default: *out = b; break;
    }
    if (*out > LIM || *out < -LIM) { c->err = "Overflow"; return false; }
    return true;
}
static void press(Calc *c, char a) {
    if (c->err && a != 'c') { reset(c); }
    int dl = 0; bool dot = false; int fd = 0;
    switch (a) {
    case 'c': reset(c); return;
    case 'e': kstrlcpy(c->entry, "0", sizeof c->entry); c->typing = true; c->have_operand = true; return;
    case 'b':
        if (c->typing) { size_t l = strlen(c->entry); if (l > 0) c->entry[l - 1] = 0; if (!c->entry[0] || !strcmp(c->entry, "-")) kstrlcpy(c->entry, "0", sizeof c->entry); }
        return;
    case '.':
        if (!c->typing) { kstrlcpy(c->entry, "0", sizeof c->entry); c->typing = true; }
        c->have_operand = true;
        for (const char *p = c->entry; *p; p++) if (*p == '.') return;
        if (strlen(c->entry) < 20) kstrlcat(c->entry, ".", sizeof c->entry);
        return;
    case 'n':
        if (c->typing) {
            if (!strcmp(c->entry, "0")) return;
            if (c->entry[0] == '-') memmove(c->entry, c->entry + 1, strlen(c->entry)); else { memmove(c->entry + 1, c->entry, strlen(c->entry) + 1); c->entry[0] = '-'; }
        } else { c->shown = -c->shown; c->have_operand = true; }
        return;
    }
    if (a >= '0' && a <= '9') {
        if (!c->typing) { c->entry[0] = 0; c->typing = true; }
        c->have_operand = true;
        if (!strcmp(c->entry, "0")) c->entry[0] = 0;
        for (const char *p = c->entry; *p; p++) { if (*p == '.') dot = true; else if (*p != '-') { if (!dot) dl++; else fd++; } }
        if ((!dot && dl >= 9) || (dot && fd >= 4)) return;
        char s[2] = { a, 0 }; kstrlcat(c->entry, s, sizeof c->entry);
        return;
    }
    i64 v = cur_val(c), r = v;
    if (a == '+' || a == '-' || a == '*' || a == '/' || a == '=') {
        char sv[24], sa[24];
        if (c->op && (c->have_operand || a == '=')) {   /* "5 + =" reuses the shown value as the second operand */
            fmt(c->acc, sa, sizeof sa); fmt(v, sv, sizeof sv);
            if (!apply(c, c->acc, c->op, v, &r)) return;
            c->acc = r;
            if (a == '=') ksnprintf(c->expr, sizeof c->expr, "%s %c %s =", sa, c->op == '*' ? 'x' : c->op, sv);
        } else if (!c->op) { c->acc = v; if (a == '=') c->expr[0] = 0; }
        c->shown = c->acc; c->typing = false; c->have_operand = false;
        if (a == '=') c->op = 0;
        else { c->op = a; fmt(c->acc, sa, sizeof sa); ksnprintf(c->expr, sizeof c->expr, "%s %c", sa, a == '*' ? 'x' : a); }
        return;
    }
    if (a == '%') { if (c->op) { if (!mul(c->acc, v, &r)) { c->err = "Overflow"; return; } r /= 100; } else r = 0; }
    else if (a == 'q') { if (!mul(v, v, &r)) { c->err = "Overflow"; return; } }
    else if (a == 'i') { if (v == 0) { c->err = "Cannot divide by zero"; return; } bool neg = v < 0; u64 uv = neg ? (u64)(-v) : (u64)v; u64 q = (u64)(SC * SC + (i64)uv / 2) / uv; r = neg ? -(i64)q : (i64)q; }
    else if (a == 'r') { if (v < 0) { c->err = "Invalid input"; return; } r = (i64)isqrt64((u64)v * SC); }
    c->shown = r; c->typing = false; c->have_operand = true;
}

static void geom(int cw, int ch, int *bw, int *bh) { *bw = (cw - 16 - 12) / 4; *bh = (ch - 108 - 8 - 20) / 6; }

static void calc_draw(Window *w, int cx, int cy, int cw, int ch) {
    Calc *c = w->data;
    gfx_rrect(cx + 8, cy + 8, cw - 16, 92, 8, T.card); gfx_rrect_border(cx + 8, cy + 8, cw - 16, 92, 8, T.border);
    gfx_text_right(cx + cw - 20, cy + 16, c->expr, T.dim);
    char num[32];
    if (c->err) kstrlcpy(num, c->err, sizeof num); else if (c->typing) kstrlcpy(num, c->entry, sizeof num); else fmt(c->shown, num, sizeof num);
    int len = (int)strlen(num), sc = (len * 24 <= cw - 40) ? 3 : (len * 16 <= cw - 40 ? 2 : 1);
    gfx_text_scaled(cx + cw - 20 - len * 8 * sc, cy + 44 + (3 - sc) * 8, num, T.text, sc);
    int bw, bh; geom(cw, ch, &bw, &bh);
    for (int i = 0; i < 24; i++) {
        int x = cx + 8 + (i % 4) * (bw + 4), y = cy + 108 + (i / 4) * (bh + 4);
        bool digit = KEYS[i].a >= '0' && KEYS[i].a <= '9', eq = KEYS[i].a == '=';
        u32 bg = eq ? T.accent : (digit || KEYS[i].a == '.' ? T.card : T.card_alt);
        gfx_rrect(x, y, bw, bh, 6, bg);
        if (!eq) gfx_rrect_border(x, y, bw, bh, 6, T.border);
        if (wm_hover(w, x, y, bw, bh)) gfx_rrect(x, y, bw, bh, 6, eq ? ARGB(40, 255, 255, 255) : T.hover);
        if (c->pressed == i) gfx_rrect(x, y, bw, bh, 6, T.press);
        gfx_text_center(x, y + (bh - 16) / 2, bw, KEYS[i].l, eq ? T.accent_text : T.text);
    }
}
static int hit(Window *w, int mx, int my) {
    int bw, bh; geom(w->w - 2, w->h - TITLE_H - 1, &bw, &bh);
    for (int i = 0; i < 24; i++) if (pt_in(8 + (i % 4) * (bw + 4), 108 + (i / 4) * (bh + 4), bw, bh, mx, my)) return i;
    return -1;
}
static void calc_mouse(Window *w, MouseKind k, int mx, int my) {
    Calc *c = w->data; int i = hit(w, mx, my);
    if (k == EV_DOWN) c->pressed = i;
    else if (k == EV_UP) { if (i >= 0 && i == c->pressed) press(c, KEYS[i].a); c->pressed = -1; }
}
static void calc_key(Window *w, const KeyEvent *e) {
    Calc *c = w->data; int k = e->key;
    if ((k >= '0' && k <= '9') || k == '.' || k == '+' || k == '-' || k == '*' || k == '/' || k == '%') press(c, (char)k);
    else if (k == KEY_ENTER || k == '=') press(c, '=');
    else if (k == KEY_BACKSPACE) press(c, 'b');
    else if (k == KEY_ESC) press(c, 'c');
    else if (k == KEY_DELETE) press(c, 'e');
}
static void calc_closed(Window *w) { kfree(w->data); }

Window *calc_open(void) {
    Calc *c = kzalloc(sizeof *c); if (!c) return 0;
    reset(c);
    Window *w = wm_create("Calculator", APP_CALC, 340, 520);
    if (!w) { kfree(c); return 0; }
    w->data = c; w->draw = calc_draw; w->key = calc_key; w->mouse = calc_mouse; w->closed = calc_closed; w->min_w = 300; w->min_h = 440;
    return w;
}
