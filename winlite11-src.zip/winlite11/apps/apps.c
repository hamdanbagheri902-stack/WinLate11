#include "apps.h"
Window *app_launch(int app) {
    switch (app) {
    case APP_EXPLORER: return explorer_open("/");
    case APP_NOTEPAD:  return notepad_open(0);
    case APP_CALC:     return calc_open();
    case APP_TERMINAL: return terminal_open();
    case APP_SETTINGS: { Window *w = wm_find_app(APP_SETTINGS); if (w) { wm_focus(w); return w; } return settings_open(); }
    }
    return 0;
}
