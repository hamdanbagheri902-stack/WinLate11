/* File Explorer: navigation pane, file list, toolbar, rename (F2), new folder/file, delete. */
#include "apps.h"
#include "../kernel/klib.h"
#include "../drivers/drivers.h"

#define ROW_H 28
#define NAV_W 150
#define HIST 16
typedef struct {
    FsNode *dir; int sel, scroll;
    FsNode *hist[HIST]; int nh;
    bool renaming, rsel; char rname[32]; int rlen;
    u32 last_click; int last_idx;
    char msg[64];
} Explorer;

static const struct { const char *label; const char *path; } NAV[] = {
    { "This PC", "/" }, { "Desktop", "/Desktop" }, { "Documents", "/Documents" },
    { "Downloads", "/Downloads" }, { "Pictures", "/Pictures" }, { "System", "/System" } };
#define NNAV 6

static void set_title(Window *w) {
    Explorer *e = w->data; char t[48];
    ksnprintf(t, sizeof t, "%s - File Explorer", e->dir->parent ? e->dir->name : "This PC");
    wm_set_title(w, t);
}
static void goto_dir(Window *w, FsNode *d, bool push) {
    Explorer *e = w->data;
    if (!d || !d->is_dir) return;
    if (push && e->dir != d) { if (e->nh < HIST) e->hist[e->nh++] = e->dir; else { memmove(e->hist, e->hist + 1, (HIST - 1) * sizeof e->hist[0]); e->hist[HIST - 1] = e->dir; } }
    e->dir = d; e->sel = -1; e->scroll = 0; e->renaming = false; e->msg[0] = 0;
    set_title(w);
}
static void go_back(Window *w) {
    Explorer *e = w->data;
    while (e->nh > 0) { FsNode *d = e->hist[--e->nh]; if (fs_valid(d)) { goto_dir(w, d, false); return; } }
}
static void go_up(Window *w) { Explorer *e = w->data; if (e->dir->parent) goto_dir(w, e->dir->parent, true); }
static void open_sel(Window *w) {
    Explorer *e = w->data; FsNode *n = fs_nth(e->dir, e->sel);
    if (!n) return;
    if (n->is_dir) goto_dir(w, n, true);
    else { char p[96]; fs_path(n, p, sizeof p); notepad_open(p); }
}
static void start_rename(Window *w) {
    Explorer *e = w->data; FsNode *n = fs_nth(e->dir, e->sel);
    if (!n) return;
    e->renaming = true; e->rsel = true; kstrlcpy(e->rname, n->name, sizeof e->rname); e->rlen = (int)strlen(e->rname);
}
static void new_item(Window *w, bool dir) {
    Explorer *e = w->data;
    FsNode *n = dir ? fs_unique(e->dir, "New folder", "", true) : fs_unique(e->dir, "New file", ".txt", false);
    if (!n) { kstrlcpy(e->msg, "Could not create item", sizeof e->msg); return; }
    for (int i = 0; i < fs_count(e->dir); i++) if (fs_nth(e->dir, i) == n) e->sel = i;
    start_rename(w);
}
static void delete_sel(Window *w) {
    Explorer *e = w->data; FsNode *n = fs_nth(e->dir, e->sel);
    if (!n) return;
    fs_remove(n); e->sel = -1; e->renaming = false; kstrlcpy(e->msg, "Item deleted", sizeof e->msg);
}
static int visible_rows(int ch) { int v = (ch - 74 - 30) / ROW_H; return v < 1 ? 1 : v; }

static void ex_draw(Window *w, int cx, int cy, int cw, int ch) {
    Explorer *e = w->data;
    if (!fs_valid(e->dir)) { e->dir = fs_root(); e->sel = -1; e->nh = 0; }
    int cnt = fs_count(e->dir);
    if (e->sel >= cnt) e->sel = -1;
    /* toolbar */
    ui_button(cx + 8, cy + 6, 32, 30, "\x88", wm_hover(w, cx + 8, cy + 6, 32, 30), false, false);
    ui_button(cx + 44, cy + 6, 44, 30, "Up", wm_hover(w, cx + 44, cy + 6, 44, 30), false, false);
    int rx = cx + cw - 8 - 68; ui_button(rx, cy + 6, 68, 30, "Delete", wm_hover(w, rx, cy + 6, 68, 30), false, false);
    rx -= 4 + 84; ui_button(rx, cy + 6, 84, 30, "New file", wm_hover(w, rx, cy + 6, 84, 30), false, false);
    rx -= 4 + 104; ui_button(rx, cy + 6, 104, 30, "New folder", wm_hover(w, rx, cy + 6, 104, 30), false, false);
    int px = cx + 94, pw = rx - 4 - px;
    if (pw > 40) {
        gfx_rrect(px, cy + 6, pw, 30, 5, T.card); gfx_rrect_border(px, cy + 6, pw, 30, 5, T.border);
        char p[96]; fs_path(e->dir, p, sizeof p);
        gfx_text_clipped(px + 10, cy + 13, pw - 20, p, T.text);
    }
    /* navigation pane */
    int nh = ch - 46 - 34;
    gfx_rrect(cx + 8, cy + 46, NAV_W, nh, 8, T.card_alt); gfx_rrect_border(cx + 8, cy + 46, NAV_W, nh, 8, T.border);
    char cur[96]; fs_path(e->dir, cur, sizeof cur);
    for (int i = 0; i < NNAV; i++) {
        int y = cy + 54 + i * 32, x = cx + 14;
        bool active = !strcmp(cur, NAV[i].path) || (i > 0 && !strncmp(cur, NAV[i].path, strlen(NAV[i].path)) && cur[strlen(NAV[i].path)] == '/');
        if (active) { gfx_rrect(x, y, NAV_W - 12, 28, 5, T.hover); gfx_rrect(x, y + 6, 3, 16, 2, T.accent); }
        else if (wm_hover(w, x, y, NAV_W - 12, 28)) gfx_rrect(x, y, NAV_W - 12, 28, 5, T.hover);
        ui_folder_icon(x + 8, y + 6, 16);
        gfx_text(x + 32, y + 6, NAV[i].label, T.text);
    }
    /* file list */
    int lx = cx + 8 + NAV_W + 8, lw = cw - (lx - cx) - 8;
    gfx_rrect(lx, cy + 46, lw, nh, 8, T.card); gfx_rrect_border(lx, cy + 46, lw, nh, 8, T.border);
    gfx_text(lx + 36, cy + 52, "Name", T.dim); gfx_text_right(lx + lw - 14, cy + 52, "Size", T.dim);
    gfx_hline(lx + 6, cy + 72, lw - 12, T.border);
    Rect old = gfx_set_clip((Rect){ lx + 1, cy + 73, lw - 2, nh - 28 });
    int vis = visible_rows(ch);
    if (e->sel >= 0) { if (e->sel < e->scroll) e->scroll = e->sel; if (e->sel >= e->scroll + vis) e->scroll = e->sel - vis + 1; }
    for (int r = 0; r < vis && e->scroll + r < cnt; r++) {
        int i = e->scroll + r, y = cy + 76 + r * ROW_H; FsNode *n = fs_nth(e->dir, i);
        if (i == e->sel) gfx_rrect(lx + 4, y, lw - 8, ROW_H - 2, 5, COL_ALPHA(T.accent, 60));
        else if (wm_hover(w, lx + 4, y, lw - 8, ROW_H - 2)) gfx_rrect(lx + 4, y, lw - 8, ROW_H - 2, 5, T.hover);
        if (n->is_dir) ui_folder_icon(lx + 10, y + 3, 20); else ui_file_icon(lx + 10, y + 3, 20);
        if (e->renaming && i == e->sel) {
            gfx_rrect(lx + 34, y + 2, lw - 150, ROW_H - 6, 4, T.win); gfx_rrect_border(lx + 34, y + 2, lw - 150, ROW_H - 6, 4, T.accent);
            if (e->rsel) gfx_rrect(lx + 38, y + 5, e->rlen * 8 + 4, 18, 3, COL_ALPHA(T.accent, 110));
            int x = gfx_text(lx + 40, y + 6, e->rname, T.text);
            if (!e->rsel) gfx_fill(x, y + 6, 2, 16, T.accent);
        } else gfx_text_clipped(lx + 36, y + 6, lw - 140, n->name, T.text);
        if (!n->is_dir) {
            char sz[24];
            if (n->size < 1024) ksnprintf(sz, sizeof sz, "%u B", n->size); else ksnprintf(sz, sizeof sz, "%u KB", (n->size + 1023) / 1024);
            gfx_text_right(lx + lw - 14, y + 6, sz, T.dim);
        }
    }
    gfx_set_clip(old);
    if (cnt == 0) gfx_text_center(lx, cy + 120, lw, "This folder is empty.", T.dim);
    char st[96];
    if (e->msg[0]) kstrlcpy(st, e->msg, sizeof st);
    else if (e->sel >= 0 && fs_nth(e->dir, e->sel)) ksnprintf(st, sizeof st, "%d items   |   1 item selected", cnt);
    else ksnprintf(st, sizeof st, "%d items", cnt);
    gfx_text(cx + 14, cy + ch - 24, st, T.dim);
}
static void commit_rename(Window *w) {
    Explorer *e = w->data; FsNode *n = fs_nth(e->dir, e->sel);
    e->renaming = false;
    if (n && strcmp(n->name, e->rname)) {
        if (fs_rename(n, e->rname)) { for (int i = 0; i < fs_count(e->dir); i++) if (fs_nth(e->dir, i) == n) e->sel = i; }
        else kstrlcpy(e->msg, "Name is empty, invalid or already used", sizeof e->msg);
    }
}
static void ex_key(Window *w, const KeyEvent *k) {
    Explorer *e = w->data; int key = k->key, cnt = fs_count(e->dir);
    e->msg[0] = 0;
    if (e->renaming) {
        if (key == KEY_ENTER) commit_rename(w);
        else if (key == KEY_ESC) e->renaming = false;
        else if (key == KEY_BACKSPACE) { if (e->rsel) { e->rlen = 0; e->rname[0] = 0; e->rsel = false; } else if (e->rlen) e->rname[--e->rlen] = 0; }
        else if (key >= 32 && key < 127 && key != '/') {
            if (e->rsel) { e->rlen = 0; e->rname[0] = 0; e->rsel = false; }      /* typing replaces the selected old name */
            if (e->rlen < 30) { e->rname[e->rlen++] = (char)key; e->rname[e->rlen] = 0; }
        }
        return;
    }
    if (key == KEY_DOWN) e->sel = imin(cnt - 1, e->sel + 1);
    else if (key == KEY_UP) e->sel = e->sel < 0 ? cnt - 1 : imax(0, e->sel - 1);
    else if (key == KEY_ENTER) open_sel(w);
    else if (key == KEY_BACKSPACE) go_up(w);
    else if (key == KEY_DELETE) delete_sel(w);
    else if (key == KEY_F2) start_rename(w);
    else if (key == KEY_HOME) e->sel = cnt ? 0 : -1;
    else if (key == KEY_END) e->sel = cnt - 1;
}
static void ex_mouse(Window *w, MouseKind k, int mx, int my) {
    Explorer *e = w->data; if (k != EV_DOWN) return;
    int cw = w->w - 2, ch = w->h - TITLE_H - 1;
    e->msg[0] = 0;
    if (e->renaming) commit_rename(w);
    if (pt_in(8, 6, 32, 30, mx, my)) { go_back(w); return; }
    if (pt_in(44, 6, 44, 30, mx, my)) { go_up(w); return; }
    int rx = cw - 8 - 68; if (pt_in(rx, 6, 68, 30, mx, my)) { delete_sel(w); return; }
    rx -= 88; if (pt_in(rx, 6, 84, 30, mx, my)) { new_item(w, false); return; }
    rx -= 108; if (pt_in(rx, 6, 104, 30, mx, my)) { new_item(w, true); return; }
    for (int i = 0; i < NNAV; i++) if (pt_in(14, 54 + i * 32, NAV_W - 12, 28, mx, my)) { goto_dir(w, fs_lookup(0, NAV[i].path), true); return; }
    int lx = 8 + NAV_W + 8, lw = cw - lx - 8;
    if (pt_in(lx, 76, lw, ch - 76 - 34, mx, my)) {
        int i = e->scroll + (my - 76) / ROW_H;
        if (i < fs_count(e->dir)) {
            u32 now = pit_ticks();
            if (i == e->last_idx && now - e->last_click < 40) { e->sel = i; open_sel(w); e->last_idx = -1; return; }
            e->sel = i; e->last_idx = i; e->last_click = now;
        } else e->sel = -1;
    }
}
static void ex_closed(Window *w) { kfree(w->data); }

Window *explorer_open(const char *path) {
    Explorer *e = kzalloc(sizeof *e); if (!e) return 0;
    Window *w = wm_create("File Explorer", APP_EXPLORER, 780, 470);
    if (!w) { kfree(e); return 0; }
    w->data = e; w->draw = ex_draw; w->key = ex_key; w->mouse = ex_mouse; w->closed = ex_closed; w->min_w = 520; w->min_h = 280;
    e->sel = -1; e->last_idx = -1;
    FsNode *d = path ? fs_lookup(0, path) : 0; e->dir = (d && d->is_dir) ? d : fs_root();
    set_title(w);
    return w;
}
