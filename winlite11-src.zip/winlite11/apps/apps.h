#pragma once
#include "../gui/wm.h"
#include "../gui/shell.h"
#include "../fs/ramfs.h"

Window *app_launch(int app);
Window *notepad_open(const char *path);      /* path may be NULL/"" for a new document */
Window *explorer_open(const char *path);
Window *calc_open(void);
Window *terminal_open(void);
Window *settings_open(void);
