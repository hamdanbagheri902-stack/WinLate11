/* Settings: Personalization (dark mode, accent color, wallpaper) and System information. */
#include "apps.h"
#include "../kernel/klib.h"
#include "../kernel/boot_info.h"
#include "../drivers/drivers.h"

typedef struct { int page; } Settings;
#define NAV_W 176

static void card(int x, int y, int w, int h) { gfx_rrect(x, y, w, h, 8, T.card); gfx_rrect_border(x, y, w, h, 8, T.border); }

static void set_draw(Window *w, int cx, int cy, int cw, int ch) {
    Settings *s = w->data;
    static const char *pages[2] = { "Personalization", "System" };
    for (int i = 0; i < 2; i++) {
        int y = cy + 12 + i * 36;
        if (s->page == i) { gfx_rrect(cx + 8, y, NAV_W - 16, 32, 6, T.hover); gfx_rrect(cx + 8, y + 8, 3, 16, 2, T.accent); }
        else if (wm_hover(w, cx + 8, y, NAV_W - 16, 32)) gfx_rrect(cx + 8, y, NAV_W - 16, 32, 6, T.hover);
        gfx_text(cx + 22, y + 8, pages[i], T.text);
    }
    int x = cx + NAV_W + 8, pw = cw - NAV_W - 24, y = cy + 14;
    gfx_text_scaled(x, y, pages[s->page], T.text, 2); y += 48;
    if (s->page == 0) {
        card(x, y, pw, 64);
        gfx_text(x + 16, y + 12, "Dark mode", T.text); gfx_text(x + 16, y + 34, "Switch between the light and dark theme", T.dim);
        ui_switch(x + pw - 56, y + 22, T.dark, wm_hover(w, x + pw - 56, y + 22, 40, 20));
        y += 76;
        card(x, y, pw, 84);
        gfx_text(x + 16, y + 12, "Accent color", T.text);
        for (int i = 0; i < ACCENT_COUNT; i++) {
            int ax = x + 30 + i * 44, ay = y + 56;
            if (wm_hover(w, ax - 18, ay - 18, 36, 36)) gfx_circle(ax, ay, 18, T.hover);
            if (i == T.accent_idx) gfx_circle(ax, ay, 17, COL_ALPHA(ACCENTS[i], 90));
            gfx_circle(ax, ay, 12, ACCENTS[i]);
            if (i == T.accent_idx) gfx_text(ax - 4, ay - 8, "\x85", 0xFFFFFFFF);
        }
        y += 96;
        card(x, y, pw, 130);
        gfx_text(x + 16, y + 12, "Wallpaper color", T.text);
        for (int i = 0; i < WALL_COUNT; i++) {
            int tx = x + 16 + (i % 3) * 112 + 0, ty = y + 36 + (i / 3) * 44 - 0;
            u32 top, bot, blob; wall_preset_info(i, &top, &bot, &blob);
            if (T.dark) { top = gfx_lerp(0xFF0A0A0A, top, 80); bot = gfx_lerp(0xFF0A0A0A, bot, 80); }
            gfx_rrect_grad(tx, ty, 100, 36, 6, 0xFF000000 | top, 0xFF000000 | bot);
            gfx_circle(tx + 86, ty + 18, 8, COL_ALPHA(blob, 160));
            if (i == T.wall_idx) gfx_rrect_border(tx - 2, ty - 2, 104, 40, 8, T.accent);
            else if (wm_hover(w, tx, ty, 100, 36)) gfx_rrect_border(tx - 1, ty - 1, 102, 38, 7, T.dim);
            gfx_text(tx + 6, ty + 10, WALL_NAMES[i], T.dark ? 0xFFFFFFFF : 0xFF1B1B1B);
        }
    } else {
        card(x, y, pw, 232);
        char v[64]; u32 up = pit_ticks() / 100;
        const char *lab[7] = { "Device name", "System", "Display", "Memory", "Kernel heap", "RAM disk", "Uptime" };
        char vals[7][64];
        kstrlcpy(vals[0], "WINLITE-PC", 64); kstrlcpy(vals[1], "WinLite 11 hobby build (i386)", 64);
        ksnprintf(vals[2], 64, "%d x %d, 32-bit color", gfx_w, gfx_h);
        ksnprintf(vals[3], 64, "%u MB installed", g_boot.mem_kb / 1024 + 1);
        ksnprintf(vals[4], 64, "%u KB used", (u32)kheap_used() / 1024);
        ksnprintf(vals[5], 64, "%u bytes in files", fs_total_bytes());
        ksnprintf(vals[6], 64, "%u min %u s", up / 60, up % 60);
        (void)v;
        for (int i = 0; i < 7; i++) {
            gfx_text(x + 16, y + 14 + i * 30, lab[i], T.dim);
            gfx_text_right(x + pw - 16, y + 14 + i * 30, vals[i], T.text);
            if (i < 6) gfx_hline(x + 12, y + 36 + i * 30, pw - 24, T.border);
        }
        y += 246;
        gfx_text(x, y, "Original code, icons and font. No Microsoft code or assets.", T.dim);
    }
}
static void set_mouse(Window *w, MouseKind k, int mx, int my) {
    Settings *s = w->data; if (k != EV_DOWN) return;
    for (int i = 0; i < 2; i++) if (pt_in(8, 12 + i * 36, NAV_W - 16, 32, mx, my)) { s->page = i; return; }
    if (s->page != 0) return;
    int x = NAV_W + 8, pw = (w->w - 2) - NAV_W - 24, y = 14 + 48;
    if (pt_in(x, y, pw, 64, mx, my)) { shell_set_theme(!T.dark, -1, -1); return; }
    y += 76;
    for (int i = 0; i < ACCENT_COUNT; i++) if (pt_in(x + 30 + i * 44 - 18, y + 56 - 18, 36, 36, mx, my)) { shell_set_theme(-1, i, -1); return; }
    y += 96;
    for (int i = 0; i < WALL_COUNT; i++) if (pt_in(x + 16 + (i % 3) * 112, y + 36 + (i / 3) * 44, 100, 36, mx, my)) { shell_set_theme(-1, -1, i); return; }
}
static void set_closed(Window *w) { kfree(w->data); }

Window *settings_open(void) {
    Settings *s = kzalloc(sizeof *s); if (!s) return 0;
    Window *w = wm_create("Settings", APP_SETTINGS, 720, 520);
    if (!w) { kfree(s); return 0; }
    w->data = s; w->draw = set_draw; w->mouse = set_mouse; w->closed = set_closed; w->min_w = 560; w->min_h = 440;
    return w;
}
