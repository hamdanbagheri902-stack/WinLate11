/* Notepad: plain-text editor with cursor movement, scrolling, mouse placement and Ctrl+S save into the RAM filesystem. */
#include "apps.h"
#include "../kernel/klib.h"
#include "../drivers/drivers.h"

#define NP_MAX 65536
typedef struct { char *buf; int len, cur, scroll_line, scroll_col, want_col; char path[96]; bool modified; } Notepad;

static const char *base_name(const char *p) { const char *b = p; for (; *p; p++) if (*p == '/') b = p + 1; return b; }
static void update_title(Window *w) {
    Notepad *n = w->data; char t[48];
    ksnprintf(t, sizeof t, "%s%s - Notepad", n->modified ? "*" : "", n->path[0] ? base_name(n->path) : "Untitled");
    wm_set_title(w, t);
}
static int line_start(Notepad *n, int idx) { while (idx > 0 && n->buf[idx - 1] != '\n') idx--; return idx; }
static int line_end(Notepad *n, int idx) { while (idx < n->len && n->buf[idx] != '\n') idx++; return idx; }
static void cur_pos(Notepad *n, int *line, int *col) {
    int l = 0, s = 0;
    for (int i = 0; i < n->cur; i++) if (n->buf[i] == '\n') { l++; s = i + 1; }
    *line = l; *col = n->cur - s;
}
static void insert(Notepad *n, const char *s, int k) {
    if (n->len + k > NP_MAX - 1) return;
    memmove(n->buf + n->cur + k, n->buf + n->cur, n->len - n->cur);
    memcpy(n->buf + n->cur, s, k); n->len += k; n->cur += k;
}
static void save(Window *w) {
    Notepad *n = w->data; FsNode *f = 0;
    if (!n->path[0]) {
        FsNode *docs = fs_lookup(0, "/Documents");
        f = fs_unique(docs ? docs : fs_root(), "Untitled", ".txt", false);
        if (f) fs_path(f, n->path, sizeof n->path);
    } else {
        f = fs_lookup(0, n->path);
        if (!f) { char leaf[32]; FsNode *d = fs_lookup_parent(0, n->path, leaf); f = fs_create(d ? d : fs_root(), leaf, false); }
    }
    if (f && fs_write(f, n->buf, (u32)n->len)) n->modified = false;
    update_title(w);
}
static void geom(int cw, int ch, int *tx, int *ty, int *tw, int *th) { *tx = 8; *ty = 46; *tw = cw - 16; *th = ch - 46 - 30; }

static void np_draw(Window *w, int cx, int cy, int cw, int ch) {
    Notepad *n = w->data;
    int tx, ty, tw, th; geom(cw, ch, &tx, &ty, &tw, &th);
    ui_button(cx + 8, cy + 6, 64, 30, "New", wm_hover(w, cx + 8, cy + 6, 64, 30), false, false);
    ui_button(cx + 78, cy + 6, 64, 30, "Save", wm_hover(w, cx + 78, cy + 6, 64, 30), false, true);
    gfx_text_clipped(cx + 156, cy + 14, cw - 164, n->path[0] ? n->path : "(not saved yet - Ctrl+S)", T.dim);
    gfx_rrect(cx + tx, cy + ty, tw, th, 6, T.card);
    gfx_rrect_border(cx + tx, cy + ty, tw, th, 6, T.border);
    int cols = (tw - 16) / 8, rows = (th - 12) / 16;
    if (cols < 1 || rows < 1) return;
    int line, col; cur_pos(n, &line, &col);
    if (line < n->scroll_line) n->scroll_line = line;
    if (line >= n->scroll_line + rows) n->scroll_line = line - rows + 1;
    if (col < n->scroll_col) n->scroll_col = col;
    if (col >= n->scroll_col + cols) n->scroll_col = col - cols + 1;
    Rect old = gfx_set_clip((Rect){ cx + tx + 4, cy + ty + 4, tw - 8, th - 8 });
    int idx = 0;
    for (int l = 0; l < n->scroll_line && idx < n->len; l++) idx = line_end(n, idx) + 1;
    for (int r = 0; r < rows && idx <= n->len; r++) {
        int e = line_end(n, idx), y = cy + ty + 6 + r * 16;
        for (int c = 0, i = idx + n->scroll_col; c < cols && i < e; c++, i++) {
            char s[2] = { n->buf[i] == '\t' ? ' ' : n->buf[i], 0 };
            gfx_text(cx + tx + 8 + c * 8, y, s, T.text);
        }
        idx = e + 1;
    }
    if (wm_top() == w && ((pit_ticks() / 50) & 1) == 0)
        gfx_fill(cx + tx + 8 + (col - n->scroll_col) * 8, cy + ty + 6 + (line - n->scroll_line) * 16, 2, 16, T.accent);
    gfx_set_clip(old);
    char st[96]; ksnprintf(st, sizeof st, "Ln %d, Col %d     %d characters", line + 1, col + 1, n->len);
    gfx_text(cx + 12, cy + ch - 24, st, T.dim);
}
static void np_key(Window *w, const KeyEvent *e) {
    Notepad *n = w->data; int k = e->key; int line, col;
    bool changed = false;
    if ((e->mods & MOD_CTRL) && k == 's') { save(w); return; }
    if (k == KEY_LEFT) { if (n->cur > 0) n->cur--; n->want_col = -1; }
    else if (k == KEY_RIGHT) { if (n->cur < n->len) n->cur++; n->want_col = -1; }
    else if (k == KEY_HOME) { n->cur = line_start(n, n->cur); n->want_col = -1; }
    else if (k == KEY_END) { n->cur = line_end(n, n->cur); n->want_col = -1; }
    else if (k == KEY_UP || k == KEY_DOWN) {
        cur_pos(n, &line, &col);
        if (n->want_col < 0) n->want_col = col;
        int target = n->want_col;
        if (k == KEY_UP) {
            int s = line_start(n, n->cur);
            if (s > 0) { int ps = line_start(n, s - 1); n->cur = ps + imin(target, s - 1 - ps); }
        } else {
            int e = line_end(n, n->cur);
            if (e < n->len) { int ns = e + 1, ne = line_end(n, ns); n->cur = ns + imin(target, ne - ns); }
        }
    }
    else if (k == KEY_BACKSPACE) { if (n->cur > 0) { memmove(n->buf + n->cur - 1, n->buf + n->cur, n->len - n->cur); n->cur--; n->len--; changed = true; } n->want_col = -1; }
    else if (k == KEY_DELETE) { if (n->cur < n->len) { memmove(n->buf + n->cur, n->buf + n->cur + 1, n->len - n->cur - 1); n->len--; changed = true; } }
    else if (k == KEY_ENTER) { insert(n, "\n", 1); changed = true; n->want_col = -1; }
    else if (k == KEY_TAB) { insert(n, "    ", 4); changed = true; n->want_col = -1; }
    else if (k >= 32 && k < 127 && !(e->mods & MOD_CTRL)) { char c = (char)k; insert(n, &c, 1); changed = true; n->want_col = -1; }
    if (changed && !n->modified) { n->modified = true; update_title(w); }
    else if (changed) update_title(w);
}
static void np_new(Window *w) {
    Notepad *n = w->data; n->len = n->cur = 0; n->scroll_line = n->scroll_col = 0; n->path[0] = 0; n->modified = false;
    update_title(w);
}
static void np_mouse(Window *w, MouseKind k, int mx, int my) {
    Notepad *n = w->data; if (k != EV_DOWN) return;
    int tx, ty, tw, th; geom(w->w - 2, w->h - TITLE_H - 1, &tx, &ty, &tw, &th);
    if (pt_in(8, 6, 64, 30, mx, my)) { np_new(w); return; }
    if (pt_in(78, 6, 64, 30, mx, my)) { save(w); return; }
    if (!pt_in(tx, ty, tw, th, mx, my)) return;
    int row = (my - (ty + 6)) / 16, col = (mx - (tx + 8)) / 8; if (row < 0) row = 0; if (col < 0) col = 0;
    int idx = 0;
    for (int l = 0; l < n->scroll_line + row && idx < n->len; l++) { int e = line_end(n, idx); if (e >= n->len) { idx = e; break; } idx = e + 1; }
    int e = line_end(n, idx);
    n->cur = idx + imin(col + n->scroll_col, e - idx); n->want_col = -1;
}
static void np_closed(Window *w) { Notepad *n = w->data; kfree(n->buf); kfree(n); }

Window *notepad_open(const char *path) {
    Notepad *n = kzalloc(sizeof *n); if (!n) return 0;
    n->buf = kzalloc(NP_MAX); n->want_col = -1;
    if (!n->buf) { kfree(n); return 0; }
    Window *w = wm_create("Untitled - Notepad", APP_NOTEPAD, 640, 460);
    if (!w) { kfree(n->buf); kfree(n); return 0; }
    w->data = n; w->draw = np_draw; w->key = np_key; w->mouse = np_mouse; w->closed = np_closed; w->min_w = 360; w->min_h = 240;
    if (path && path[0]) {
        FsNode *f = fs_lookup(0, path);
        if (f && !f->is_dir) {
            n->len = (int)(f->size < NP_MAX - 1 ? f->size : NP_MAX - 1);
            if (n->len) memcpy(n->buf, f->data, n->len);
            for (int i = 0; i < n->len; i++) if (n->buf[i] == '\r') n->buf[i] = ' ';
            kstrlcpy(n->path, path, sizeof n->path);
        }
    }
    update_title(w);
    return w;
}
