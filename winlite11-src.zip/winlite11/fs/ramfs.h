#pragma once
#include "../kernel/types.h"
typedef struct FsNode {
    char name[32]; bool is_dir;
    struct FsNode *parent, *child, *next;
    u8 *data; u32 size, cap;
} FsNode;

void    fs_init(void);
FsNode *fs_root(void);
FsNode *fs_lookup(FsNode *cwd, const char *path);                         /* abs/relative, "." and ".." */
FsNode *fs_lookup_parent(FsNode *cwd, const char *path, char *leaf32);    /* dir that would hold path + leaf name */
FsNode *fs_create(FsNode *dir, const char *name, bool is_dir);           /* NULL if invalid name or exists */
FsNode *fs_unique(FsNode *dir, const char *base, const char *ext, bool is_dir);  /* "New folder", "New folder 2", ... */
bool    fs_write(FsNode *f, const void *data, u32 n);
bool    fs_append(FsNode *f, const void *data, u32 n);
bool    fs_remove(FsNode *n);
bool    fs_rename(FsNode *n, const char *newname);
bool    fs_valid(FsNode *n);                                              /* still in the tree? */
void    fs_path(FsNode *n, char *buf, size_t sz);
int     fs_count(FsNode *dir);
FsNode *fs_nth(FsNode *dir, int i);
u32     fs_total_bytes(void);
