/* In-memory filesystem: tree of nodes, children kept sorted (folders first, then name, case-insensitive). */
#include "ramfs.h"
#include "../kernel/klib.h"

static FsNode *root;

static int ci_cmp(const char *a, const char *b) {
    while (*a && ktolower(*a) == ktolower(*b)) { a++; b++; }
    return ktolower((u8)*a) - ktolower((u8)*b);
}
static void insert_sorted(FsNode *dir, FsNode *n) {
    FsNode **pp = &dir->child;
    while (*pp) {
        FsNode *c = *pp;
        if (c->is_dir != n->is_dir) { if (n->is_dir) break; }
        else if (ci_cmp(c->name, n->name) > 0) break;
        pp = &c->next;
    }
    n->next = *pp; *pp = n; n->parent = dir;
}
static FsNode *find_child(FsNode *dir, const char *name) {
    for (FsNode *c = dir->child; c; c = c->next) if (!ci_cmp(c->name, name)) return c;
    return 0;
}
FsNode *fs_root(void) { return root; }

FsNode *fs_lookup(FsNode *cwd, const char *path) {
    FsNode *cur = (path[0] == '/') ? root : (cwd ? cwd : root);
    char part[40]; const char *p = path;
    while (*p) {
        while (*p == '/') p++;
        if (!*p) break;
        int n = 0;
        while (*p && *p != '/') { if (n < 39) part[n++] = *p; p++; }
        part[n] = 0;
        if (!strcmp(part, ".")) continue;
        if (!strcmp(part, "..")) { if (cur->parent) cur = cur->parent; continue; }
        if (!cur->is_dir) return 0;
        cur = find_child(cur, part);
        if (!cur) return 0;
    }
    return cur;
}
FsNode *fs_lookup_parent(FsNode *cwd, const char *path, char *leaf) {
    int len = (int)strlen(path);
    while (len > 1 && path[len - 1] == '/') len--;
    int slash = -1;
    for (int i = 0; i < len; i++) if (path[i] == '/') slash = i;
    char dirpath[96];
    if (slash < 0) { kstrlcpy(dirpath, ".", sizeof dirpath); }
    else if (slash == 0) { kstrlcpy(dirpath, "/", sizeof dirpath); }
    else { int n = slash < 95 ? slash : 95; memcpy(dirpath, path, n); dirpath[n] = 0; }
    int ln = len - (slash + 1); if (ln > 31) ln = 31; if (ln < 0) ln = 0;
    memcpy(leaf, path + slash + 1, ln); leaf[ln] = 0;
    FsNode *d = fs_lookup(cwd, dirpath);
    return (d && d->is_dir) ? d : 0;
}
FsNode *fs_create(FsNode *dir, const char *name, bool is_dir) {
    if (!dir || !dir->is_dir || !name[0] || strlen(name) > 31) return 0;
    if (!strcmp(name, ".") || !strcmp(name, "..")) return 0;
    for (const char *c = name; *c; c++) if (*c == '/' || (u8)*c < 32) return 0;
    if (find_child(dir, name)) return 0;
    FsNode *n = kzalloc(sizeof *n);
    if (!n) return 0;
    kstrlcpy(n->name, name, sizeof n->name); n->is_dir = is_dir;
    insert_sorted(dir, n);
    return n;
}
FsNode *fs_unique(FsNode *dir, const char *base, const char *ext, bool is_dir) {
    char name[40];
    for (int i = 1; i < 1000; i++) {
        if (i == 1) ksnprintf(name, sizeof name, "%s%s", base, ext);
        else ksnprintf(name, sizeof name, "%s %d%s", base, i, ext);
        if (!find_child(dir, name)) return fs_create(dir, name, is_dir);
    }
    return 0;
}
bool fs_write(FsNode *f, const void *d, u32 n) {
    if (!f || f->is_dir) return false;
    if (n > f->cap) {
        u8 *nb = kmalloc(n + 64);
        if (!nb) return false;
        kfree(f->data); f->data = nb; f->cap = n + 64;
    }
    if (n) memcpy(f->data, d, n);
    f->size = n; return true;
}
bool fs_append(FsNode *f, const void *d, u32 n) {
    if (!f || f->is_dir) return false;
    if (f->size + n > f->cap) {
        u32 nc = (f->size + n) * 2 + 64;
        u8 *nb = kmalloc(nc);
        if (!nb) return false;
        if (f->size) memcpy(nb, f->data, f->size);
        kfree(f->data); f->data = nb; f->cap = nc;
    }
    memcpy(f->data + f->size, d, n); f->size += n; return true;
}
static void free_tree(FsNode *n) {
    for (FsNode *c = n->child; c;) { FsNode *nx = c->next; free_tree(c); c = nx; }
    kfree(n->data); kfree(n);
}
static void unlink_node(FsNode *n) {
    for (FsNode **pp = &n->parent->child; *pp; pp = &(*pp)->next)
        if (*pp == n) { *pp = n->next; break; }
    n->next = 0;
}
static bool contains(FsNode *t, FsNode *n) {
    if (t == n) return true;
    for (FsNode *c = t->child; c; c = c->next) if (contains(c, n)) return true;
    return false;
}
bool fs_valid(FsNode *n) { return n && root && contains(root, n); }
bool fs_remove(FsNode *n) {
    if (!n || !fs_valid(n) || !n->parent) return false;
    unlink_node(n); free_tree(n); return true;
}
bool fs_rename(FsNode *n, const char *nm) {
    if (!n || !n->parent || !nm[0] || strlen(nm) > 31 || !strcmp(nm, ".") || !strcmp(nm, "..")) return false;
    for (const char *c = nm; *c; c++) if (*c == '/' || (u8)*c < 32) return false;
    FsNode *ex = find_child(n->parent, nm);
    if (ex && ex != n) return false;
    FsNode *par = n->parent;
    unlink_node(n); kstrlcpy(n->name, nm, sizeof n->name); insert_sorted(par, n);
    return true;
}
void fs_path(FsNode *n, char *buf, size_t sz) {
    if (!n->parent) { kstrlcpy(buf, "/", sz); return; }
    char tmp[128]; fs_path(n->parent, tmp, sizeof tmp);
    if (tmp[1]) kstrlcat(tmp, "/", sizeof tmp);
    kstrlcat(tmp, n->name, sizeof tmp);
    kstrlcpy(buf, tmp, sz);
}
int fs_count(FsNode *d) { int k = 0; for (FsNode *c = d->child; c; c = c->next) k++; return k; }
FsNode *fs_nth(FsNode *d, int i) { FsNode *c = d->child; while (c && i-- > 0) c = c->next; return c; }
static u32 total(FsNode *n) { u32 t = n->size; for (FsNode *c = n->child; c; c = c->next) t += total(c); return t; }
u32 fs_total_bytes(void) { return total(root); }

static void put(FsNode *dir, const char *name, const char *text) {
    FsNode *f = fs_create(dir, name, false);
    if (f) fs_write(f, text, (u32)strlen(text));
}
void fs_init(void) {
    root = kzalloc(sizeof *root); root->is_dir = true; kstrlcpy(root->name, "/", sizeof root->name);
    FsNode *desk = fs_create(root, "Desktop", true), *docs = fs_create(root, "Documents", true);
    fs_create(root, "Downloads", true);
    FsNode *pics = fs_create(root, "Pictures", true), *sys = fs_create(root, "System", true);
    put(desk, "hello.txt", "Hello from the WinLite 11 desktop!\n");
    put(docs, "Welcome.txt",
        "Welcome to WinLite 11\n=====================\n\n"
        "This is a hobby operating system with a Windows 11-inspired desktop.\n"
        "Everything you see is original code: the kernel, the window manager,\n"
        "the icons and the font.\n\n"
        "Try this:\n"
        "  - Open the Start menu and type to search.\n"
        "  - Drag windows by their title bar, resize from the bottom-right corner.\n"
        "  - Open Settings to switch to dark mode and change the wallpaper.\n"
        "  - Open Terminal and type 'help'.\n\n"
        "Files live in RAM and disappear when the machine restarts.\n");
    put(docs, "Todo.txt", "- Add a real disk driver\n- Networking?\n- Write more apps\n");
    put(docs, "Ideas.txt", "Notepad can save with Ctrl+S.\nExplorer can rename with F2.\n");
    put(pics, "readme.txt", "No image viewer yet - see the roadmap in README.md.\n");
    put(sys, "about.txt", "WinLite 11 - hobby OS. i386, Multiboot2, no external libraries.\n");
}
